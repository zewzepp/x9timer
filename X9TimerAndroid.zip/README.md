# X9Timer (Android, Gradle)

The web app lives in `app/src/main/assets/` and runs inside a WebView.
Edit those files, push, and GitHub Actions builds the APK
(Actions tab -> latest run -> Artifacts).
Local build: `gradle assembleDebug` (needs JDK 17 + Android SDK).

## Design system (v2)
- `x9.css` is the single stylesheet. Tokens at the top: graphite body, six sticker colours, keycap buttons.
- Fonts are bundled in `assets/fonts/` (Archivo Black, DM Sans, Anonymous Pro; all OFL). The app works fully offline.
- `sfx.js` synthesises every sound (no sample files) and also drives haptics via `X9Native.haptic()`.
- Settings now has Sound effects, Volume and Haptics.
