# X9Timer — Android

X9Timer is an Android app built with a native Android WebView shell and bundled web assets.

## Build
- JDK 17
- Android SDK (compile SDK 34)
- Gradle 8.7

Run `gradle assembleDebug`. GitHub Actions also builds the debug APK on push or manual dispatch; download `X9Timer-debug-apk` from the workflow artifacts.

## Design update
- Added a compact X9 cube monogram for the in-app brand and launcher artwork.
- Added `x9-redesign.css` as the final design layer, preserving the existing timer/training mechanics while standardizing typography, spacing, contrast, controls, and feature surfaces.
- Includes dark and light palettes, small-screen layout adjustments, keyboard focus states, and reduced-motion support.
- Existing timer, sessions, training modes, sound engine, and local persistence remain in the original app code.

## Branding and package identity
- Android application ID: `com.x9timer.app`.
- Debug APK output filename: `com.x9timer.app.apk`.
- Uses the supplied X9 cube logo for the home screen and launcher artwork.
- Updated the primary accent system to light blue to match the supplied logo.
