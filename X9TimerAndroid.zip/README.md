# X9Timer (Android, Gradle)

The web app lives in `app/src/main/assets/` and runs inside a WebView.
Edit those files, push, and GitHub Actions builds the APK
(Actions tab -> latest run -> Artifacts -> X9Timer-debug-apk).
Local build: `gradle assembleDebug` (needs JDK 17 + Android SDK).
