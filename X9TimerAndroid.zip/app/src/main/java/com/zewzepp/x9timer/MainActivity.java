package com.zewzepp.x9timer;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.ActivityManager;
import android.app.AlertDialog;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.VibrationEffect;
import android.os.Vibrator;
import android.speech.tts.TextToSpeech;
import android.view.View;
import android.view.WindowManager;
import android.webkit.JavascriptInterface;
import android.webkit.JsPromptResult;
import android.webkit.JsResult;
import android.widget.EditText;
import android.webkit.PermissionRequest;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import androidx.webkit.WebViewAssetLoader;

import java.util.Locale;

public class MainActivity extends Activity {
    private static final int PICK = 41;
    private WebView web;
    private ValueCallback<Uri[]> picker;
    private TextToSpeech tts;
    private boolean ttsReady = false;

    /** Exposed to the web app as window.X9Native */
    public class Native {
        @JavascriptInterface
        public void keepOn(final boolean on) {
            runOnUiThread(() -> {
                if (on) getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
                else getWindow().clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
            });
        }

        @JavascriptInterface
        public void copy(final String text) {
            runOnUiThread(() -> {
                ClipboardManager cm = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
                if (cm != null) cm.setPrimaryClip(ClipData.newPlainText("X9Timer", text));
            });
        }


        /** Real haptics (the WebView's navigator.vibrate needs the VIBRATE permission and is unreliable).
         *  1 tick, 2 click, 3 heavy, 4 celebrate, 5 error */
        @JavascriptInterface
        public void haptic(final int kind) {
            try {
                final Vibrator v = (Vibrator) getSystemService(Context.VIBRATOR_SERVICE);
                if (v == null || !v.hasVibrator()) return;
                if (Build.VERSION.SDK_INT < 26) { v.vibrate(kind == 3 ? 30 : kind == 1 ? 8 : 16); return; }
                VibrationEffect e;
                switch (kind) {
                    case 4: e = VibrationEffect.createWaveform(new long[]{0, 18, 40, 18, 40, 36}, -1); break;
                    case 5: e = VibrationEffect.createWaveform(new long[]{0, 30, 50, 30}, -1); break;
                    default:
                        if (Build.VERSION.SDK_INT >= 29) {
                            int id = kind == 1 ? VibrationEffect.EFFECT_TICK : kind == 3 ? VibrationEffect.EFFECT_HEAVY_CLICK : VibrationEffect.EFFECT_CLICK;
                            e = VibrationEffect.createPredefined(id);
                        } else {
                            e = VibrationEffect.createOneShot(kind == 1 ? 8 : kind == 3 ? 30 : 16, VibrationEffect.DEFAULT_AMPLITUDE);
                        }
                }
                v.vibrate(e);
            } catch (Throwable t) { /* haptics are optional */ }
        }

        /** Keeps the status/navigation bars the same colour as the app theme. */
        @JavascriptInterface
        public void theme(final boolean dark) {
            runOnUiThread(() -> applyTheme(dark));
        }

        @JavascriptInterface
        public boolean lite() {
            try {
                ActivityManager am = (ActivityManager) getSystemService(Context.ACTIVITY_SERVICE);
                ActivityManager.MemoryInfo mi = new ActivityManager.MemoryInfo();
                am.getMemoryInfo(mi);
                boolean lowRam = am.isLowRamDevice();
                boolean smallMem = mi.totalMem > 0 && mi.totalMem < 4L * 1024 * 1024 * 1024;
                boolean fewCores = Runtime.getRuntime().availableProcessors() <= 4;
                boolean old = Build.VERSION.SDK_INT <= 28;
                return lowRam || smallMem || fewCores || old;
            } catch (Throwable t) {
                return false;
            }
        }
    }

    /** Exposed to the web app as window.AndroidTTS (inspection voice alert) */
    public class Voice {
        @JavascriptInterface
        public void speak(String text) {
            if (tts != null && ttsReady) tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, "x9");
        }
    }


    private void applyTheme(boolean dark) {
        int c = dark ? 0xFF26272B : 0xFFE4E5E8;
        getWindow().setStatusBarColor(c);
        getWindow().setNavigationBarColor(c);
        if (web != null) web.setBackgroundColor(c);
        View d = getWindow().getDecorView();
        int f = d.getSystemUiVisibility();
        int light = View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR | (Build.VERSION.SDK_INT >= 26 ? View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR : 0);
        d.setSystemUiVisibility(dark ? (f & ~light) : (f | light));
    }

    @SuppressLint({"SetJavaScriptEnabled", "AddJavascriptInterface"})
    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        setVolumeControlStream(android.media.AudioManager.STREAM_MUSIC);

        tts = new TextToSpeech(getApplicationContext(), status -> {
            if (status == TextToSpeech.SUCCESS) {
                tts.setLanguage(Locale.getDefault());
                ttsReady = true;
            }
        });

        web = new WebView(this);
        web.setBackgroundColor(0xFF26272B);
        setContentView(web);

        // serves bundled files from https://appassets.androidplatform.net/ (secure origin: localStorage, IndexedDB, WebRTC work)
        final WebViewAssetLoader loader = new WebViewAssetLoader.Builder()
                .addPathHandler("/", new WebViewAssetLoader.AssetsPathHandler(this))
                .build();

        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setAllowFileAccess(false);
        s.setBuiltInZoomControls(false);
        s.setSupportZoom(false);
        web.setOverScrollMode(View.OVER_SCROLL_NEVER);
        web.addJavascriptInterface(new Native(), "X9Native");
        web.addJavascriptInterface(new Voice(), "AndroidTTS");

        web.setWebViewClient(new WebViewClient() {
            @Override
            public WebResourceResponse shouldInterceptRequest(WebView v, WebResourceRequest r) {
                return loader.shouldInterceptRequest(r.getUrl());
            }
        });
        web.setWebChromeClient(new WebChromeClient() {
            @Override
            public void onPermissionRequest(PermissionRequest r) { r.deny(); }

            // window.prompt / confirm / alert do nothing in a bare WebView, so show real dialogs (used by Rename session)
            @Override
            public boolean onJsPrompt(WebView v, String url, String msg, String def, final JsPromptResult r) {
                final EditText et = new EditText(MainActivity.this);
                et.setText(def == null ? "" : def);
                et.setSingleLine(true);
                new AlertDialog.Builder(MainActivity.this)
                        .setTitle(msg)
                        .setView(et)
                        .setPositiveButton("OK", (d, w) -> r.confirm(et.getText().toString()))
                        .setNegativeButton("Cancel", (d, w) -> r.cancel())
                        .setOnCancelListener(d -> r.cancel())
                        .show();
                return true;
            }

            @Override
            public boolean onJsConfirm(WebView v, String url, String msg, final JsResult r) {
                new AlertDialog.Builder(MainActivity.this)
                        .setMessage(msg)
                        .setPositiveButton("OK", (d, w) -> r.confirm())
                        .setNegativeButton("Cancel", (d, w) -> r.cancel())
                        .setOnCancelListener(d -> r.cancel())
                        .show();
                return true;
            }

            @Override
            public boolean onJsAlert(WebView v, String url, String msg, final JsResult r) {
                new AlertDialog.Builder(MainActivity.this)
                        .setMessage(msg)
                        .setPositiveButton("OK", (d, w) -> r.confirm())
                        .setOnCancelListener(d -> r.confirm())
                        .show();
                return true;
            }

            // makes <input type="file"> work (custom background image / video)
            @Override
            public boolean onShowFileChooser(WebView v, ValueCallback<Uri[]> cb, FileChooserParams p) {
                if (picker != null) picker.onReceiveValue(null);
                picker = cb;
                Intent i = new Intent(Intent.ACTION_GET_CONTENT);
                i.addCategory(Intent.CATEGORY_OPENABLE);
                i.setType("*/*");
                i.putExtra(Intent.EXTRA_MIME_TYPES, new String[]{"image/*", "video/*"});
                try {
                    startActivityForResult(Intent.createChooser(i, "Choose background"), PICK);
                } catch (Exception e) {
                    picker = null;
                    return false;
                }
                return true;
            }
        });

        if (b != null) web.restoreState(b);
        else web.loadUrl("https://appassets.androidplatform.net/index.html");
    }

    @Override
    protected void onActivityResult(int req, int res, Intent data) {
        super.onActivityResult(req, res, data);
        if (req == PICK && picker != null) {
            Uri[] r = null;
            if (res == RESULT_OK && data != null) r = WebChromeClient.FileChooserParams.parseResult(res, data);
            picker.onReceiveValue(r);
            picker = null;
        }
    }

    @Override
    protected void onSaveInstanceState(Bundle o) {
        super.onSaveInstanceState(o);
        web.saveState(o);
    }

    @Override
    public void onBackPressed() {
        if (web.canGoBack()) web.goBack(); else super.onBackPressed();
    }

    @Override protected void onPause() { super.onPause(); web.onPause(); }
    @Override protected void onResume() { super.onResume(); web.onResume(); }

    @Override
    protected void onDestroy() {
        if (tts != null) { tts.stop(); tts.shutdown(); }
        super.onDestroy();
    }
}
