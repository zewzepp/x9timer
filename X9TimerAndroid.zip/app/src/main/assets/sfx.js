/* X9 sound + haptics, all synthesised (no sample files).
   Palette: soft mechanical keyboard. Every sound is a "burger" - thin layers stacked a few ms apart on top of each other:
   tick (top bun) + clack (mid click) + thock (pitched body) + bloom (soft low tail). Pitch/volume jitter on every hit so it never repeats exactly.
   window.SFX.play(name,force) ; SFX.cfg({ui,vol,vib}) ; SFX.run(name,time) ; SFX.ac() */
(()=>{
let ac=null,out=null,dest=null,cfg={ui:1,vol:100,vib:1},last={},act=0,nb=null,introG=null;
const AC=window.AudioContext||window.webkitAudioContext;
function ctx(){
  if(!AC)return null;
  if(!ac){
    try{
      try{ac=new AC({latencyHint:'interactive'})}catch(_){ac=new AC()}
      out=ac.createGain();
      const c=ac.createDynamicsCompressor();
      c.threshold.value=-14;c.knee.value=12;c.ratio.value=6;c.attack.value=.002;c.release.value=.12;
      out.connect(c);c.connect(ac.destination);dest=out;lvl();
    }catch(e){ac=null;return null}
  }
  if(ac.state=='suspended')ac.resume().catch(()=>{});
  return ac;
}
function lvl(){if(out)out.gain.value=Math.pow(Math.max(0,Math.min(100,cfg.vol))/100,1.3)*1.6}
const done=n=>{act++;n.onended=()=>{act--}};
const R=a=>1+(Math.random()*2-1)*a;           /* random multiplier 1±a */
const st=n=>261.63*Math.pow(2,n/12);           /* semitones above C4 */

/* ---- primitives ---- */
function tone(t,f,d,v,type,f2){
  const o=ac.createOscillator(),g=ac.createGain();
  o.type=type||'sine';o.frequency.setValueAtTime(f,t);
  if(f2)o.frequency.exponentialRampToValueAtTime(Math.max(20,f2),t+d);
  g.gain.setValueAtTime(.0001,t);
  g.gain.exponentialRampToValueAtTime(Math.max(.0002,v),t+.004);
  g.gain.exponentialRampToValueAtTime(.0001,t+d);
  o.connect(g);g.connect(dest);o.start(t);o.stop(t+d+.03);done(o);
}
function noise(t,d,f0,f1,v,q,type){
  if(!nb){nb=ac.createBuffer(1,ac.sampleRate,ac.sampleRate);const a=nb.getChannelData(0);for(let i=0;i<a.length;i++)a[i]=Math.random()*2-1}
  const s=ac.createBufferSource(),f=ac.createBiquadFilter(),g=ac.createGain();
  s.buffer=nb;s.loop=true;f.type=type||'bandpass';f.Q.value=q||1;
  f.frequency.setValueAtTime(f0,t);if(f1)f.frequency.exponentialRampToValueAtTime(f1,t+d);
  g.gain.setValueAtTime(.0001,t);g.gain.exponentialRampToValueAtTime(Math.max(.0002,v),t+Math.min(.006,d/3));g.gain.exponentialRampToValueAtTime(.0001,t+d);
  s.connect(f);f.connect(g);g.connect(dest);s.start(t,Math.random()*.5);s.stop(t+d+.03);done(s);
}
/* THE BURGER: 4 layers stacked a few ms apart.  f = body pitch (Hz), v = volume, o.soft 0..1 (muffled), o.d = length scale */
function key(t,f,v,o){
  o=o||{};const s=o.soft||0,D=o.d||1,p=R(.05);v*=R(.1);
  noise(t,.008,(5600-s*2600)*p,0,v*.32*(1-s*.5),.7,'highpass');                         /* top bun: tick   */
  noise(t+.003,.026*D,(2400-s*1000)*R(.07),1000*p,v*.6,1.3,'bandpass');                /* patty: clack    */
  tone(t+.008,f*1.55*p,.075*D,v*.62,'sine',f*.8*p);                                    /* thock: pitched body */
  tone(t+.014,f*.5*p,.13*D,v*.36,'triangle',f*.34*p);                                  /* bottom bun: soft bloom */
}
/* soft glassy ping layered UNDER a key for rewards (kept quiet so it stays mechanical) */
function ping(t,f,d,v){const p=R(.012);tone(t,f*p,d,v,'sine');tone(t,f*2.01*p,d*.3,v*.18,'sine')}
/* airy swish for wipes */
function swish(t,d,v){noise(t,d,500*R(.1),3200,v,.6,'bandpass')}

/* ---- recipes (each takes the start time) ---- */
const FX={
  /* timer */
  hold:t=>key(t,150,.5,{soft:.6,d:.8}),
  ready:t=>{key(t,st(-2),.5,{soft:.3});key(t+.06,st(5),.5);ping(t+.06,st(12),.22,.1)},
  start:t=>{key(t,330,.55,{d:.7});swish(t,.07,.08)},
  stop:t=>{key(t,105,1,{d:1.7});tone(t+.01,88,.22,.45,'sine',48)},
  pb:t=>{key(t,105,.9,{d:1.5});[0,4,7,12,16].forEach((s,i)=>{key(t+.11+i*.075,st(s-5),.4,{soft:.3});ping(t+.11+i*.075,st(s+12),.5,.1)});tone(t+.11,130,.8,.14,'sine')},
  split:t=>{key(t,260,.45,{soft:.2,d:.7});ping(t,st(9+12),.14,.06)},
  cancel:t=>{key(t,190,.35,{soft:.8,d:.8});tone(t+.02,360,.1,.1,'triangle',230)},
  /* inspection alerts (8 s, 12 s) */
  al1:t=>{key(t,st(9),.55);ping(t,st(21),.3,.12)},
  al2:t=>{key(t,st(14),.55);ping(t,st(26),.2,.12);key(t+.16,st(14),.55);ping(t+.16,st(26),.3,.12)},
  /* general UI */
  pick:t=>key(t,320,.38,{soft:.5,d:.7}),
  pop:t=>{key(t,400,.3,{soft:.7,d:.6});tone(t,520,.07,.08,'sine',900)},
  on:t=>{key(t,st(7),.38,{soft:.3});key(t+.07,st(14),.36,{soft:.3})},
  del:t=>{swish(t,.16,.2);key(t,150,.5,{soft:.6,d:1.2})},
  undo:t=>{key(t,380,.32,{soft:.5,d:.7});key(t+.07,st(14),.3,{soft:.5,d:.7})},
  save:t=>{key(t,st(4),.4,{soft:.3});key(t+.08,st(11),.4,{soft:.2});ping(t+.08,st(23),.3,.09)},
  flip:t=>key(t,250,.45,{soft:.4,d:.7}),
  cat:t=>{key(t,200,.55,{d:1});key(t+.05,st(7),.3,{soft:.4,d:.8});swish(t,.12,.06)},
  correct:t=>{key(t,st(7),.42,{soft:.3});key(t+.07,st(14),.4);ping(t+.07,st(26),.35,.1)},
  wrong:t=>{key(t,130,.55,{soft:1,d:1.3});tone(t+.01,210,.22,.18,'triangle',140)},
  /* 1v1 */
  vtick:t=>key(t,300,.4,{soft:.5,d:.6}),
  vgo:t=>{key(t,st(0),.55,{d:1.2});key(t+.01,st(12),.4);ping(t,st(24),.4,.12);swish(t,.06,.1)},
  vpoint:t=>{key(t,st(4),.42,{soft:.3});key(t+.09,st(11),.42);ping(t+.09,st(23),.3,.1)},
  vloss:t=>{key(t,200,.45,{soft:.8});key(t+.1,150,.4,{soft:.9,d:1.2})},
  vwin:t=>{[0,4,7,12].forEach((s,i)=>{key(t+i*.1,st(s),.4,{soft:.2});ping(t+i*.1,st(s+12),.5,.09)});[0,7,16].forEach(s=>ping(t+.45,st(s+12),.9,.12));key(t+.45,110,.6,{d:1.5})},
  vlose:t=>{[7,4,0].forEach((s,i)=>key(t+i*.16,st(s-7),.34,{soft:.9,d:1.2}))},
  /* startup: nine stickers click into place, flip into the X, the name lands */
  intro:t=>{
    introG=ac.createGain();introG.gain.value=1;introG.connect(out);dest=introG;
    for(let i=0;i<9;i++)key(t+.06+i*.045,300+i*38,.14,{soft:.5,d:.6});
    [0,0,1,1,2,2,3,3,5].forEach((q,i)=>{if(i%2==0||q==5)key(t+1.03+q*.085,190+q*55,.42,{soft:.2})});
    swish(t+1.3,.38,.12);
    key(t+1.46,95,.7,{d:1.8});[0,7,12].forEach(s=>ping(t+1.46,st(s+12),1,.1));
    dest=out;
  },
  exit:t=>{swish(t,.2,.14);key(t,260,.3,{soft:.7,d:.8})}
};

/* ---- haptics: 1 tick, 2 click, 3 heavy, 4 celebrate, 5 error ---- */
const HAP={hold:1,ready:2,start:2,stop:3,pb:4,split:1,cancel:1,wrong:5,correct:2,vgo:3,vpoint:2,vtick:1,al1:2,al2:2,save:2,del:2};
const WEB={1:[8],2:[16],3:[30],4:[18,40,18,40,36],5:[30,50,30]};
function hap(n){
  if(!cfg.vib)return;const k=HAP[n];if(!k)return;
  try{
    if(window.X9Native&&X9Native.haptic)X9Native.haptic(k);
    else if(navigator.vibrate)navigator.vibrate(WEB[k]);
  }catch(e){}
}
const GAP={pb:600,stop:120,vtick:150,vgo:300,vwin:600,vlose:600,exit:300,intro:1000};
const KEY={exit:1,vgo:1,vwin:1,vlose:1,pb:1,stop:1};
function play(n,force,gm){
  const f=FX[n];if(!f)return;
  const now=performance.now();if(now-(last[n]||0)<(GAP[n]||40))return;last[n]=now;
  hap(n);
  if(!force&&!cfg.ui)return;
  const a=ctx();if(!a||a.state!='running')return;
  if(act>30&&!KEY[n])return;
  try{f(a.currentTime+.005,gm)}catch(e){}
}
/* tapping a mode tile on the home screen is the only click that makes a sound by itself */
document.addEventListener('click',e=>{
  const b=e.target.closest&&e.target.closest('button');if(!b)return;
  if(b.closest('.big'))setTimeout(()=>play('cat'),0);
},true);
const unlock=()=>ctx();
['pointerdown','touchend','keydown'].forEach(n=>addEventListener(n,unlock,{passive:true,capture:true}));
window.SFX={
  play,
  cfg(o){if(o){if(o.ui!=null)cfg.ui=+o.ui?1:0;if(o.vol!=null)cfg.vol=+o.vol;if(o.vib!=null)cfg.vib=+o.vib?1:0;lvl()}return cfg},
  unlock,
  ready:()=>Promise.resolve(null),
  fadeIntro(ms){if(!introG||!ac)return;const t=ac.currentTime,g=introG.gain;introG=null;g.cancelScheduledValues(t);g.setValueAtTime(g.value,t);g.linearRampToValueAtTime(0,t+ms/1000)},
  ac:ctx,
  run(n,t){const a=ctx();if(a&&FX[n])try{FX[n](t==null?a.currentTime+.005:t)}catch(e){}}
};
})();
