/* X9 sound effects v3: sampled clips (sfxdata.js) + a few WebAudio synth recipes.
   window.SFX.play(name,force,gainMul) ; SFX.cfg({ui:1,vol:70}) ; SFX.ac() ; SFX.run(name,time) */
(()=>{
let ac=null,out=null,cfg={ui:1,vol:100},last={},act=0,nb=null;
const AC=window.AudioContext||window.webkitAudioContext;
function ctx(){
  if(!AC)return null;
  if(!ac){
    try{
      try{ac=new AC({latencyHint:'interactive'})}catch(_){ac=new AC()}
      out=ac.createGain();
      /* limiter: lets the sounds be loud without clipping */
      const c=ac.createDynamicsCompressor();
      c.threshold.value=-12;c.knee.value=8;c.ratio.value=10;c.attack.value=.002;c.release.value=.14;
      out.connect(c);c.connect(ac.destination);
      lvl();
    }catch(e){ac=null;return null}
  }
  if(ac.state=='suspended')ac.resume().catch(()=>{});
  return ac;
}
function lvl(){if(out)out.gain.value=Math.max(0,Math.min(1.25,1))*1.7}
const done=n=>{act++;n.onended=()=>{act--}};
/* one oscillator with a fast attack and an exponential fade */
function tone(t,f,d,v,type,f2){
  const o=ac.createOscillator(),g=ac.createGain();
  o.type=type||'sine';o.frequency.setValueAtTime(f,t);
  if(f2)o.frequency.exponentialRampToValueAtTime(f2,t+d);
  g.gain.setValueAtTime(.0001,t);
  g.gain.exponentialRampToValueAtTime(v,t+.004);
  g.gain.exponentialRampToValueAtTime(.0001,t+d);
  o.connect(g);g.connect(out);o.start(t);o.stop(t+d+.03);done(o);
}
/* filtered noise burst (shared 1 s buffer, random start so repeats do not sound identical) */
function noise(t,d,f0,f1,v,q,type){
  if(!nb){
    nb=ac.createBuffer(1,ac.sampleRate,ac.sampleRate);
    const a=nb.getChannelData(0);for(let i=0;i<a.length;i++)a[i]=Math.random()*2-1;
  }
  const s=ac.createBufferSource(),f=ac.createBiquadFilter(),g=ac.createGain();
  s.buffer=nb;s.loop=true;
  f.type=type||'bandpass';f.Q.value=q||1;
  f.frequency.setValueAtTime(f0,t);
  if(f1)f.frequency.exponentialRampToValueAtTime(f1,t+d);
  g.gain.setValueAtTime(.0001,t);
  g.gain.exponentialRampToValueAtTime(v,t+Math.min(.008,d/3));
  g.gain.exponentialRampToValueAtTime(.0001,t+d);
  s.connect(f);f.connect(g);g.connect(out);s.start(t,Math.random()*.5);s.stop(t+d+.03);done(s);
}
/* a very short bright tick */
const click=(t,v,f)=>noise(t,.014,f||2600,0,v,.7,'highpass');
/* bell: a few inharmonic partials with their own decays */
function bell(t,f,d,v){
  tone(t,f,d,v);
  tone(t,f*2.76,d*.5,v*.3,'sine');
  tone(t,f*5.4,d*.25,v*.1,'sine');
}
/* sampled clips: decoded once from the base64 mp3s in sfxdata.js */
const BUF={},PEND={};
function decodeAll(){
  const a=ctx(),D=window.SFXD;if(!a||!D)return;
  Object.keys(D).forEach(k=>{
    if(BUF[k]||PEND[k])return;
    const bin=atob(D[k]),u=new Uint8Array(bin.length);for(let i=0;i<bin.length;i++)u[i]=bin.charCodeAt(i);
    PEND[k]=new Promise(res=>{
      const ok=b=>{BUF[k]=b;res(b)},no=()=>res(null);
      try{const p=a.decodeAudioData(u.buffer,ok,no);if(p&&p.then)p.then(ok,no)}catch(e){no()}
    });
  });
}
function go(b,t,v){
  const s=ac.createBufferSource(),g=ac.createGain();
  s.buffer=b;g.gain.value=v;s.connect(g);g.connect(out);s.start(t);done(s);
}
/* v = clip level, m = optional extra gain from the caller (the 1v1 countdown uses 3x) */
const smp=(k,v)=>(t,m)=>{
  const vv=v*(m||1);
  if(BUF[k])go(BUF[k],t,vv);
  else if(PEND[k])PEND[k].then(b=>{if(b&&ac)go(b,Math.max(t,ac.currentTime),vv)});
};
/* sound recipes, each takes the start time */
/* intro track: bass impact, cinematic hit, rapid overlay, digital outro. fadeIntro() cuts it cleanly if the intro is skipped */
let introG=null;
const introFx=t=>{const play=(b,t)=>{const s=ac.createBufferSource(),g=ac.createGain();s.buffer=b;g.gain.value=.9;s.connect(g);g.connect(out);s.start(t);done(s);introG=g};
  if(BUF.intro)play(BUF.intro,t);else if(PEND.intro)PEND.intro.then(b=>{if(b&&ac)play(b,Math.max(t,ac.currentTime))})};
const FX={
  cat:smp('active',.95),                // choosing a category: UI Active
  intro:introFx,                        // intro: bass impact > cinematic + rapid > digital outro
  exit:smp('exit',.9),                  // intro end: UI Exit
  vtick:smp('pop',.9),                  // 1v1 countdown tick: UI Pop
  vgo:smp('start',.95),                 // 1v1 countdown reaches zero: UI Start
  vpoint:smp('select',.85),             // you score a round: UI Select
  vloss:smp('minimise',.9),             // opponent scores a round: UI Minimise
  vwin:smp('wondering',.95),            // you win the match: Wondering
  vlose:smp('lowslow',.9),              // you lose the match: Low Slow Whoosh
  /* Clean cinematic swishes: short filtered noise ramps into a tonal landing. */
  loading:t=>{noise(t,.42,260,5200,.55,.7);tone(t+.18,220,.32,.32,'sine',880);bell(t+.34,880,.55,.22);tone(t+.08,110,.36,.22,'triangle',55)},
  home:t=>{noise(t,.34,300,3600,.48,.8);tone(t,330,.28,.28,'sine',660);bell(t+.22,660,.48,.2)},
  sel1:t=>sel(t,740), sel2:t=>sel(t,932), sel3:t=>sel(t,1109),
  stop:t=>{noise(t,.32,3200,180,.62,.75);tone(t+.08,180,.32,.42,'sine',65);tone(t+.2,520,.22,.18,'triangle',260)},
  pb:t=>{noise(t,.36,500,5200,.48,.7);[523.25,659.25,783.99,1046.5,1318.5].forEach((f,i)=>bell(t+.12+i*.09,f,.65,.25));tone(t+.1,130.81,1,.24);tone(t+.1,196,1,.16)},
  correct:t=>{noise(t,.18,700,5000,.4,.8);tone(t+.06,660,.24,.28,'triangle',990);bell(t+.14,1320,.4,.2)},
  wrong:t=>{noise(t,.22,2600,180,.38,.8);tone(t+.04,260,.26,.28,'triangle',145);tone(t+.14,190,.24,.18,'sine',115)}
};
Object.assign(FX,{
  hold:smp('toggle',.55),               // pad pressed
  ready:smp('select',.8),               // pad turned green
  start:smp('start',.9),                // timer starts
  stop:smp('quick',.9),                 // timer stops: Quick Whoosh
  pb:smp('wondering',.95),              // new personal best
  split:smp('scroll',.8),               // multiphase split
  pick:smp('toggle',.7),                // menu pick / volume preview
  on:smp('pop',.8),                     // sound turned on / phones linked
  correct:smp('select',.9),             // PLL / weak-case: right answer
  wrong:smp('minimise',.95)             // PLL / weak-case: wrong answer
});
function sel(t,f){noise(t,.34,260,5000,.5,.75);tone(t,120,.26,.32,'sine',55);tone(t+.08,f*.45,.28,.2,'triangle',f);bell(t+.2,f,.48,.25);bell(t+.27,f*1.5,.38,.15)}
const GAP={cat:120,hold:60,ready:60,start:100,split:80,pick:80,on:120,exit:300,vtick:150,vgo:300,vpoint:250,vloss:250,vwin:600,vlose:600,sel1:180,sel2:180,sel3:180,loading:500,home:350,stop:250,pb:600,correct:100,wrong:100};
const KEY={exit:1,vgo:1,vwin:1,vlose:1,pb:1,stop:1,loading:1,home:1};
function play(n,force,gm){
  if(!force&&!cfg.ui)return;
  const f=FX[n];if(!f)return;
  const now=performance.now();if(now-(last[n]||0)<(GAP[n]||60))return;last[n]=now;
  const a=ctx();if(!a||a.state!='running')return;
  if(act>26&&!KEY[n])return;
  try{f(a.currentTime+.005,gm)}catch(e){}
}
/* Only category selection gets click-triggered SFX. All other UI clicks are silent. */
function pickSound(el){
  if(el.closest('.big'))return'cat';
  return null;
}
document.addEventListener('click',e=>{
  const b=e.target.closest&&e.target.closest('button');if(!b)return;
  const n=pickSound(b);if(n)setTimeout(()=>play(n),0);
},true);
/* unlock audio on the first touch / key so timer sounds (which fire from timeouts) are allowed */
const unlock=()=>{ctx();decodeAll()};
['pointerdown','touchend','keydown'].forEach(n=>addEventListener(n,unlock,{passive:true,capture:true}));
try{decodeAll()}catch(e){}
window.SFX={
  play,
  cfg(o){if(o){if(o.ui!=null)cfg.ui=+o.ui?1:0;if(o.vol!=null)cfg.vol=+o.vol;lvl()}return cfg},
  unlock,
  ready:n=>PEND[n]||Promise.resolve(null),
  fadeIntro(ms){if(!introG||!ac)return;const t=ac.currentTime,g=introG.gain;introG=null;g.cancelScheduledValues(t);g.setValueAtTime(g.value,t);g.linearRampToValueAtTime(0,t+ms/1000)},
  ac:ctx,                                   // shared context (used by the splash screen)
  run(n,t){const a=ctx();if(a&&FX[n])try{FX[n](t==null?a.currentTime+.005:t)}catch(e){}}
};
})();
