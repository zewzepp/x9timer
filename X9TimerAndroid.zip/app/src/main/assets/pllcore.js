/* X9 PLL engine: 3x3 sticker model, the 21 PLL cases, case generator and cross-colour schemes (no DOM). */
(function(root){
'use strict';
var CW={x:function(v){return[v[0],v[2],-v[1]]},y:function(v){return[-v[2],v[1],v[0]]},z:function(v){return[v[1],-v[0],v[2]]}};
var FN={U:[0,1,0],D:[0,-1,0],F:[0,0,1],B:[0,0,-1],R:[1,0,0],L:[-1,0,0]},FACES='URFDLB';
var all=function(){return true};
// move -> [rotation axis, layer test, quarter turns for a clockwise move]
var MV={
 R:['x',function(p){return p[0]==1},1],L:['x',function(p){return p[0]==-1},3],
 U:['y',function(p){return p[1]==1},1],D:['y',function(p){return p[1]==-1},3],
 F:['z',function(p){return p[2]==1},1],B:['z',function(p){return p[2]==-1},3],
 M:['x',function(p){return p[0]==0},3],E:['y',function(p){return p[1]==0},3],S:['z',function(p){return p[2]==0},1],
 r:['x',function(p){return p[0]>=0},1],l:['x',function(p){return p[0]<=0},3],
 u:['y',function(p){return p[1]>=0},1],d:['y',function(p){return p[1]<=0},3],
 f:['z',function(p){return p[2]>=0},1],b:['z',function(p){return p[2]<=0},3],
 x:['x',all,1],y:['y',all,1],z:['z',all,1]};

function solved(){var s=[],x,y,z,i,f,n,a;
 for(x=-1;x<2;x++)for(y=-1;y<2;y++)for(z=-1;z<2;z++){var p=[x,y,z];
  for(i=0;i<6;i++){f=FACES[i];n=FN[f];a=n.findIndex(function(v){return v});if(p[a]==n[a])s.push({p:p.slice(),n:n.slice(),f:f})}}
 return s}
function parse(alg){var out=[],t=(alg||'').trim().split(/\s+/),i,m;
 for(i=0;i<t.length;i++){if(!t[i])continue;m=/^([URFDLBMESxyzurfdlb])(w?)(2'?|')?$/.exec(t[i]);if(!m)throw new Error('bad move '+t[i]);
  var f=m[1];if(m[2]&&f==f.toUpperCase())f=f.toLowerCase();
  out.push({f:f,k:m[3]?(m[3]=="'"?3:2):1})}
 return out}
function inverse(alg){return parse(alg).reverse().map(function(m){return m.f+(m.k==1?"'":m.k==3?'':'2')}).join(' ')}
function turnMv(s,mv){var d=MV[mv.f],ax=d[0],times=(d[2]*mv.k)%4,i,t;
 for(i=0;i<s.length;i++){var q=s[i];if(d[1](q.p))for(t=0;t<times;t++){q.p=CW[ax](q.p);q.n=CW[ax](q.n)}}}
function apply(s,alg){var mv=parse(alg),i;for(i=0;i<mv.length;i++)turnMv(s,mv[i]);return s}
function clone(s){return s.map(function(q){return{p:q.p.slice(),n:q.n.slice(),f:q.f}})}
function centersOk(s){return s.every(function(q){var z=(q.p[0]==0)+(q.p[1]==0)+(q.p[2]==0);return z<2||q.p.join()==FN[q.f].join()})}
// turn the whole cube until every centre sits where it belongs (slice moves and cube rotations move the centres)
function fixOrient(s){if(centersOk(s))return s;
 for(var a=0;a<4;a++)for(var b=0;b<4;b++)for(var c=0;c<4;c++){var t=clone(s),i,k;
  for(i=0;i<t.length;i++){for(k=0;k<a;k++){t[i].p=CW.x(t[i].p);t[i].n=CW.x(t[i].n)}for(k=0;k<b;k++){t[i].p=CW.y(t[i].p);t[i].n=CW.y(t[i].n)}for(k=0;k<c;k++){t[i].p=CW.z(t[i].p);t[i].n=CW.z(t[i].n)}}
  if(centersOk(t))return t}
 return s}

// the 21 PLLs: [name, group, algorithm that solves it]
var GROUPS=['Edges only','Corners only','Adjacent corner swap','Diagonal corner swap','G perms'];
var RAW=[
 ['H',0,"M2 U' M2 U2 M2 U' M2"],
 ['Ua',0,"R U' R U R U R U' R' U' R2"],
 ['Ub',0,"R2 U R U R' U' R' U' R' U R'"],
 ['Z',0,"M2 U' M2 U' M' U2 M2 U2 M' U2"],
 ['Aa',1,"x R' U R' D2 R U' R' D2 R2 x'"],
 ['Ab',1,"x R2 D2 R U R' D2 R U' R x'"],
 ['E',1,"x' R U' R' D R U R' D' R U R' D R U' R' D' x"],
 ['T',2,"R U R' U' R' F R2 U' R' U' R U R' F'"],
 ['F',2,"R' U' F' R U R' U' R' F R2 U' R' U' R U R' U R"],
 ['Ja',2,"R' U L' U2 R U' R' U2 R L U'"],
 ['Jb',2,"R U R' F' R U R' U' R' F R2 U' R' U'"],
 ['Ra',2,"R U' R' U' R U R D R' U' R D' R' U2 R' U'"],
 ['Rb',2,"R' U2 R U2 R' F R U R' U' R' F' R2 U'"],
 ['Y',3,"F R U' R' U' R U R' F' R U R' U' R' F R F'"],
 ['V',3,"R' U R' U' y R' F' R2 U' R' U R' F R F y'"],
 ['Na',3,"R U R' U R U R' F' R U R' U' R' F R2 U' R' U2 R U' R'"],
 ['Nb',3,"R' U R U' R' F' U' F R U R' F R' F' R U' R"],
 ['Ga',4,"R2 U R' U R' U' R U' R2 D U' R' U R D'"],
 ['Gb',4,"R' U' R U D' R2 U R' U R U' R U' R2 D"],
 ['Gc',4,"R2 U' R U' R U R' U R2 D' U R U' R' D"],
 ['Gd',4,"R U R' U' D R2 U' R U' R' U R' U R2 D'"]];
var CASES=RAW.map(function(r){return{name:r[0],g:r[1],alg:r[2]}});

// state after "inverse of the alg" with an optional U turn before (a) and after (b); every cube sticker is {p,n,f}
function caseState(i,a,b){var s=solved(),c=CASES[i];
 apply(s,(a?'U'+(a==2?'2':a==3?"'":''):'')+' '+inverse(c.alg)+' '+(b?'U'+(b==2?'2':b==3?"'":''):''));return fixOrient(s)}

// ---- face / cell lookup shared by the 3D cube and the little top views ----
// returns [face, row, col] of a sticker (same layout the on-screen cube uses)
function cell(q){var p=q.p,n=q.n;
 if(n[1]==1)return['U',p[2]+1,p[0]+1];
 if(n[1]==-1)return['D',1-p[2],p[0]+1];
 if(n[2]==1)return['F',1-p[1],p[0]+1];
 if(n[2]==-1)return['B',1-p[1],1-p[0]];
 if(n[0]==1)return['R',1-p[1],1-p[2]];
 return['L',1-p[1],p[2]+1]}

// ---- colour schemes: put the chosen cross colour on the bottom, keep the cube a real (right-handed) cube ----
var HEX={white:'#f5f5f5',yellow:'#ffd23f',green:'#25c26e',blue:'#2f7bff',red:'#ef4444',orange:'#ff8a1f'};
var BASE={U:'white',D:'yellow',F:'green',B:'blue',R:'red',L:'orange'};
var CROSSFACE={white:'U',yellow:'D',green:'F',blue:'B',red:'R',orange:'L'};
var ROT={U:['z','z'],D:[],F:['x','x','x'],B:['x'],R:['z'],L:['z','z','z']};
var LET=function(v){for(var l in FN)if(FN[l].join()==v.join())return l};
function scheme(cross){var out={},seq=ROT[CROSSFACE[cross]],g;
 for(g in BASE){var v=FN[g];seq.forEach(function(r){v=CW[r](v)});out[LET(v)]=HEX[BASE[g]]}
 return out}

// ---- checks used by the tests ----
var CPOS=[[1,1,1],[-1,1,1],[-1,1,-1],[1,1,-1]],EPOS=[[0,1,1],[-1,1,0],[0,1,-1],[1,1,0]];
var CH={FR:0,FL:1,BL:2,BR:3},EH={F:0,L:1,B:2,R:3};
// where each top-layer piece went: cp[position]=home position of the corner sitting there, ep likewise for edges
function perms(s){var cp=[],ep=[];
 CPOS.forEach(function(P){var fs=s.filter(function(q){return q.p.join()==P.join()}).map(function(q){return q.f}).filter(function(f){return f!='U'}).sort().join('');cp.push(CH[fs])});
 EPOS.forEach(function(P){var f=s.filter(function(q){return q.p.join()==P.join()}).map(function(q){return q.f}).filter(function(f){return f!='U'})[0];ep.push(EH[f])});
 return{cp:cp,ep:ep}}
// bottom two layers solved and every top sticker is the top colour
function lastLayerOnly(s){return s.every(function(q){if(q.p[1]<1)return q.n.join()==FN[q.f].join();return q.n[1]!=1||q.f=='U'})}

root.PLLC={CASES:CASES,GROUPS:GROUPS,HEX:HEX,solved:solved,apply:apply,inverse:inverse,parse:parse,fixOrient:fixOrient,caseState:caseState,cell:cell,scheme:scheme,perms:perms,lastLayerOnly:lastLayerOnly,clone:clone};
if(typeof module!=='undefined')module.exports=root.PLLC;
})(typeof window!=='undefined'?window:globalThis);
