/* Cross trainer: white-cross scrambles with an exact optimal cross length (level = moves). No timer. */
(()=>{
const FACES='URFDLB';let R=Math.random;const pick=a=>a[R()*a.length|0];
function rnd(len){const o=[];let l='',p='';while(o.length<len){const f=pick(FACES),a=FACES.indexOf(f)%3;if(f==l||(l&&p&&a==FACES.indexOf(l)%3&&a==FACES.indexOf(p)%3))continue;o.push(f+pick(['',"'",'2']));p=l;l=f}return o.join(' ')}
// crossDist measures the cross on the U face, i.e. the white cross for a white-top scramble
const merge=s=>{const o=[];for(const t of s.split(' ')){const f=t[0],k=t[1]=='2'?2:t[1]=="'"?3:1,p=o[o.length-1];if(p&&p[0]==f){const n=(p[1]+k)%4;o.pop();if(n)o.push([f,n])}else o.push([f,k])}return o.map(([f,k])=>f+['','','2',"'"][k]).join(' ')};
// low levels: take a random scramble and trim its cross down to the level; high levels: keep drawing until the cross length matches
function gen(lv,C){R=C.rnd;let s;for(let i=0;i<300000;i++){s=rnd(20);const d=C.crossDist(s);if(d==lv)return s;if(lv<4&&d>lv)return merge(C.crossTo(s,lv))}return s}
if(typeof document==='undefined'){module.exports={gen};return}
const $=i=>document.getElementById(i),C=window.X9C,body=$('ctBody');
const label=n=>`Level ${n} – Cross requires ${n} move${n>1?'s':''} to solve`;
let lv=1;try{lv=Math.min(8,Math.max(1,+localStorage.getItem('x9-ct-lvl')||1))}catch(e){}
body.innerHTML=`<div class="ct-dd" id="ctDd"><button type="button" class="ct-dt" id="ctDt" aria-haspopup="listbox" aria-expanded="false"><span id="ctDl"></span><svg class="i" viewBox="0 0 24 24" aria-hidden="true"><path d="M6 9l6 6 6-6"/></svg></button><div class="ct-dp" id="ctDp" role="listbox">${[1,2,3,4,5,6,7,8].map(n=>`<button type="button" role="option" data-l="${n}"><span>${label(n)}</span><i class="ct-r"></i></button>`).join('')}</div></div>
<div class="ct-card"><span class="lbl">Scramble</span><div class="ct-scr" id="ctScr"></div><small>White cross · white on top, green front</small></div>
<button type="button" class="pill ok ct-go" id="ctGo">Randomize</button>`;
const dd=$('ctDd'),dt=$('ctDt'),scr=$('ctScr'),opts=[...dd.querySelectorAll('[data-l]')];
let has=false;
function mark(){$('ctDl').textContent=label(lv);opts.forEach(o=>{const on=+o.dataset.l==lv;o.classList.toggle('on',on);o.setAttribute('aria-selected',on)})}
function open(v){dd.classList.toggle('open',v);dt.setAttribute('aria-expanded',v)}
function next(){scr.textContent=gen(lv,C);has=true}
dt.onclick=()=>open(!dd.classList.contains('open'));
dd.addEventListener('click',e=>{const o=e.target.closest('[data-l]');if(!o)return;lv=+o.dataset.l;try{localStorage.setItem('x9-ct-lvl',lv)}catch(_){}mark();open(false);next()});
$('ctGo').onclick=next;
addEventListener('pointerdown',e=>{if(!dd.contains(e.target))open(false)},{passive:true});
addEventListener('keydown',e=>{if(e.key=='Escape')open(false)});
$('ctHome').onclick=()=>{open(false);history.back()};
mark();
new MutationObserver(()=>{if($('vctrain').classList.contains('on')){if(!has)setTimeout(next,30)}else open(false)}).observe($('vctrain'),{attributes:true,attributeFilter:['class']});
})();
