/* X9Timer · PLL Recognition: a 3D cube you can spin, and the 21 PLL names to choose from. */
(()=>{
const $=i=>document.getElementById(i),C=window.PLLC;if(!C||!$('vpll'))return;
const P=n=>{try{SFX.play(n)}catch(e){}},RM=matchMedia('(prefers-reduced-motion: reduce)').matches;
const CASES=C.CASES,CROSS=['white','yellow','green','blue','red','orange'];
const ALPHA=CASES.map((_,i)=>i).sort((a,b)=>CASES[a].name<CASES[b].name?-1:1);
const clamp=(v,a,b)=>Math.max(a,Math.min(b,v));
const S={sel:new Set(CASES.map((_,i)=>i)),cross:'white',crosses:new Set(['white']),mode:'all',cur:-1,locked:false,t0:0,ok:0,n:0,streak:0,best:0,ms:0,view:[-28,-35],quiz:false};

// ---- saved choices ----
try{const x=JSON.parse(localStorage.getItem('x9pll'));if(x){
 if(CROSS.includes(x.cross))S.cross=x.cross;if(Array.isArray(x.crosses)){const cs=x.crosses.filter(c=>CROSS.includes(c)).slice(0,6);if(cs.length)S.crosses=new Set(cs)}else if(CROSS.includes(x.cross))S.crosses=new Set([x.cross]);if(x.mode=='sel')S.mode='sel';
 if(Array.isArray(x.sel)){const set=new Set(x.sel.map(nm=>CASES.findIndex(c=>c.name==nm)).filter(i=>i>=0));if(set.size)S.sel=set}}}catch(e){}
const save=()=>{try{localStorage.setItem('x9pll',JSON.stringify({cross:S.cross,crosses:[...S.crosses],mode:S.mode,sel:[...S.sel].map(i=>CASES[i].name)}))}catch(e){}};

// ================= setup screen =================
const HEX=C.HEX;
function buildCols(){$('rcCols').innerHTML=CROSS.map(c=>`<button type="button" class="rc-col${S.crosses.has(c)?' on':''}" data-c="${c}" style="--c:${HEX[c]}" aria-label="${c} cross" aria-pressed="${S.crosses.has(c)}"></button>`).join('')}
// little top-down picture of a case: the top face with the three stickers of each side of the top layer
function mini(i){const sc=C.scheme(S.cross),st=C.caseState(i,0,0);let h='',r,c;
 for(r=0;r<3;r++)for(c=0;c<3;c++)h+=`<rect x="${15+c*10}" y="${15+r*10}" width="10" height="10" fill="${sc.U}"/>`;
 st.forEach(q=>{if(q.p[1]!=1||q.n[1]!=0)return;const f=sc[q.f];let x,y,w=10,hh=5;
  if(q.n[2]==1){x=15+(q.p[0]+1)*10;y=46}else if(q.n[2]==-1){x=15+(q.p[0]+1)*10;y=9}
  else if(q.n[0]==1){x=46;y=15+(q.p[2]+1)*10;w=5;hh=10}else{x=9;y=15+(q.p[2]+1)*10;w=5;hh=10}
  h+=`<rect x="${x}" y="${y}" width="${w}" height="${hh}" rx="1" fill="${f}"/>`});
 return`<svg viewBox="0 0 60 60" aria-hidden="true">${h}</svg>`}
function buildPick(){let h='';
 C.GROUPS.forEach((g,gi)=>{const L=CASES.map((c,i)=>[c,i]).filter(([c])=>c.g==gi);
  h+=`<div class="gh"><span>${g}<small>${L.length}</small></span><button type="button" class="pill tiny" data-g="${gi}">Toggle</button></div><div class="grid">`+
   L.map(([c,i])=>`<button type="button" class="tile${S.sel.has(i)?' on':''}" data-i="${i}">${mini(i)}${c.name}</button>`).join('')+'</div>'});
 $('rcPick').innerHTML=h}
function sync(){const n=S.mode==='all'?CASES.length:S.sel.size;$('rcCnt').textContent=n;$('rcN').textContent=n;$('rcStart').disabled=!n;document.getElementById('rcPick').classList.toggle('disabled-picks',S.mode==='all');document.getElementById('rcAll').disabled=S.mode==='all';document.getElementById('rcNone').disabled=S.mode==='all';
 document.querySelectorAll('#rcPick .tile').forEach(t=>t.classList.toggle('on',S.sel.has(+t.dataset.i)));
 document.querySelectorAll('#rcMode button').forEach(b=>b.classList.toggle('on',b.dataset.m==S.mode));
 $('rcModeNote').textContent=S.mode=='all'?'All 21 PLL cases are included. Case selection is disabled.':'Only the cases you select will appear.';save()}
$('rcCols').addEventListener('click',e=>{const b=e.target.closest('.rc-col');if(!b)return;const c=b.dataset.c;if(S.crosses.has(c)){if(S.crosses.size===1)return;S.crosses.delete(c)}else{if(S.crosses.size>=6)return;S.crosses.add(c)}S.cross=[...S.crosses][0];buildCols();buildPick();sync()});
$('rcMode').addEventListener('click',e=>{const b=e.target.closest('button');if(!b)return;S.mode=b.dataset.m;sync()});
$('rcPick').addEventListener('click',e=>{const t=e.target.closest('.tile'),g=e.target.closest('[data-g]');
 if(S.mode==='all')return;if(t){const i=+t.dataset.i;S.sel.has(i)?S.sel.delete(i):S.sel.add(i)}
 else if(g){const ids=CASES.map((c,i)=>c.g==+g.dataset.g?i:-1).filter(i=>i>=0),all=ids.every(i=>S.sel.has(i));ids.forEach(i=>all?S.sel.delete(i):S.sel.add(i))}
 else return;sync()});
$('rcAll').onclick=()=>{if(S.mode==='all')return;S.sel=new Set(CASES.map((_,i)=>i));sync()};
$('rcNone').onclick=()=>{if(S.mode==='all')return;S.sel.clear();sync()};

// ================= the 3D cube =================
const stage=$('rcStage'),scene=$('rcScene'),cube=$('rcCube'),cells={},faceEl={};
['U','D','F','B','R','L'].forEach(f=>{const d=document.createElement('div');d.className='rc-f';d.dataset.f=f;cells[f]=[];
 for(let i=0;i<9;i++){const e=document.createElement('i');e.className='rc-c';d.appendChild(e);cells[f].push(e)}cube.appendChild(d);faceEl[f]=d});
const NRM={F:[0,0,1],B:[0,0,-1],R:[1,0,0],L:[-1,0,0],U:[0,-1,0],D:[0,1,0]},LIGHT=(()=>{const v=[.3,-.65,.7],m=Math.hypot(...v);return v.map(x=>x/m)})();
let rx=-28,ry=-35,vrx=0,vry=0,tw=0,gl=0,drag=false,lx=0,ly=0,lt=0,lm=0;
function shade(){const a=ry*Math.PI/180,b=rx*Math.PI/180,ca=Math.cos(a),sa=Math.sin(a),cb=Math.cos(b),sb=Math.sin(b);
 for(const f in NRM){const[x,y,z]=NRM[f],x1=x*ca+z*sa,z1=-x*sa+z*ca,y2=y*cb-z1*sb,z2=y*sb+z1*cb,d=x1*LIGHT[0]+y2*LIGHT[1]+z2*LIGHT[2];
  faceEl[f].style.setProperty('--sh',clamp(.3-.42*d,0,.62).toFixed(3))}}
function setRot(){cube.style.transform=`rotateX(${rx.toFixed(2)}deg) rotateY(${ry.toFixed(2)}deg)`;shade()}
const stopAnim=()=>{cancelAnimationFrame(tw);cancelAnimationFrame(gl);tw=gl=0};
function tweenTo(x1,y1,ms,short){stopAnim();if(short)y1=ry+(((y1-ry)%360)+540)%360-180;
 if(RM||!ms){rx=x1;ry=y1;setRot();return}
 const x0=rx,y0=ry,t0=performance.now(),step=now=>{const k=Math.min(1,(now-t0)/ms),e=1-Math.pow(1-k,3);rx=x0+(x1-x0)*e;ry=y0+(y1-y0)*e;setRot();tw=k<1?requestAnimationFrame(step):0};tw=requestAnimationFrame(step)}
function glide(){let last=performance.now();const step=now=>{const dt=Math.min(40,now-last);last=now;
 ry+=vry*dt;rx=clamp(rx+vrx*dt,-90,90);if(rx==-90||rx==90)vrx=0;const f=Math.exp(-dt/300);vry*=f;vrx*=f;setRot();
 gl=Math.abs(vry)+Math.abs(vrx)>.004?requestAnimationFrame(step):0};gl=requestAnimationFrame(step)}
const K=.5; // degrees per pixel
stage.addEventListener('pointerdown',e=>{if(e.target.closest('button'))return;stopAnim();drag=true;lx=e.clientX;ly=e.clientY;lt=lm=e.timeStamp;vrx=vry=0;
 try{stage.setPointerCapture(e.pointerId)}catch(_){}stage.classList.add('grab','used')});
stage.addEventListener('pointermove',e=>{if(!drag)return;const dx=e.clientX-lx,dy=e.clientY-ly,dt=Math.max(1,e.timeStamp-lt);lx=e.clientX;ly=e.clientY;lt=lm=e.timeStamp;
 ry+=dx*K;rx=clamp(rx-dy*K,-90,90);vry=vry*.55+(dx*K/dt)*.45;vrx=vrx*.55+(-dy*K/dt)*.45;setRot()});
const up=e=>{if(!drag)return;drag=false;stage.classList.remove('grab');if(e.timeStamp-lm>90){vrx=vry=0;return}
 if(Math.abs(vry)+Math.abs(vrx)>.02&&!RM)glide()};
stage.addEventListener('pointerup',up);stage.addEventListener('pointercancel',up);
const reset=()=>tweenTo(S.view[0],S.view[1],450,true);
$('rcReset').onclick=reset;stage.addEventListener('dblclick',e=>{if(!e.target.closest('button'))reset()});
function sizeCube(){const r=stage.getBoundingClientRect();if(!r.width)return;scene.style.setProperty('--s',clamp(Math.min(r.width,r.height)*.56,90,300).toFixed(0)+'px')}
if(window.ResizeObserver)new ResizeObserver(sizeCube).observe(stage);else addEventListener('resize',sizeCube);

function paint(st){const sc=C.scheme(S.cross);st.forEach(q=>{const[f,r,c]=C.cell(q);cells[f][r*3+c].style.backgroundColor=sc[q.f]})}

// ================= quiz =================
let bag=[],autoT=0;
function draw(){if(!bag.length){const pool=S.mode==='all'?CASES.map((_,i)=>i):[...S.sel];bag=[...pool];for(let i=bag.length-1;i>0;i--){const j=Math.random()*(i+1)|0;[bag[i],bag[j]]=[bag[j],bag[i]]}
 if(bag.length>1&&bag[bag.length-1]==S.cur){const t=bag[0];bag[0]=bag[bag.length-1];bag[bag.length-1]=t}}return bag.pop()}
const ansList=()=>S.mode=='all'?ALPHA:ALPHA.filter(i=>S.sel.has(i));
const btn=i=>$('rcAns').querySelector(`[data-i="${i}"]`);
function buildAns(){$('rcAns').innerHTML=ansList().map(i=>`<button type="button" class="rc-a" data-i="${i}"><span class="rc-a-img">${mini(i)}</span><span>${CASES[i].name}</span></button>`).join('')}
function stats(){$('rcScore').textContent=S.n?`${S.ok}/${S.n}`:'0/0';$('rcStreak').textContent=S.streak;$('rcAvg').textContent=S.n?(S.ms/S.n/1000).toFixed(1)+' s':'–'}
function next(){clearTimeout(autoT);if(!(S.mode==='all'?CASES.length:S.sel.size))return;S.cross=[...S.crosses][Math.random()*S.crosses.size|0];buildCols();buildAns();const i=draw();S.cur=i;S.locked=false;$('rcQuiz').classList.remove('lock');
 paint(C.caseState(i,Math.random()*4|0,Math.random()*4|0));
 S.view=[-28,-35+90*(Math.random()*4|0)];rx=-28;ry=S.view[1]-110;setRot();tweenTo(S.view[0],S.view[1],RM?0:420);
 $('rcAns').querySelectorAll('.rc-a').forEach(b=>b.className='rc-a');
 $('rcFb').innerHTML='<div class="rc-hint">Which PLL is this?</div>';
 S.t0=performance.now()}
function answer(i){if(S.locked)return;S.locked=true;$('rcQuiz').classList.add('lock');
 const ms=performance.now()-S.t0,ok=i==S.cur,c=CASES[S.cur];S.n++;S.ms+=ms;
 if(ok){S.ok++;S.streak++;S.best=Math.max(S.best,S.streak)}else S.streak=0;
 btn(i).classList.add(ok?'ok':'no');if(!ok){const r=btn(S.cur);r&&r.classList.add('rev')}
 $('rcFb').innerHTML=ok?`<div class="rc-fbt good">Correct · ${c.name}<small>${(ms/1000).toFixed(1)} s</small></div>`
  :`<div class="rc-fbrow"><div class="rc-fbt bad">It's ${c.name}<small>not ${CASES[i].name}</small></div><button type="button" class="pill tiny rc-next">Next</button></div><div class="rc-alg">${c.alg}</div>`;
 stats();if(ok){P('correct');autoT=setTimeout(next,750)}else P('wrong')}
$('rcAns').addEventListener('click',e=>{const b=e.target.closest('.rc-a');if(!b)return;b.blur();answer(+b.dataset.i)});
$('rcFb').addEventListener('click',e=>{if(e.target.closest('.rc-next')){e.target.blur();next()}});
addEventListener('keydown',e=>{if(document.body.dataset.v!='pll'||!S.quiz)return;
 if((e.code=='Space'||e.key=='Enter')&&S.locked&&$('rcFb').querySelector('.rc-next')){e.preventDefault();next()}
 else if(e.key=='r'||e.key=='R')reset()});

function showQuiz(){S.quiz=true;$('rcSetup').hidden=true;$('rcQuiz').hidden=false;$('rcBack').hidden=false;stage.classList.remove('used');
 S.ok=S.n=S.streak=S.best=S.ms=0;S.cur=-1;bag=[];stats();buildAns();requestAnimationFrame(()=>{sizeCube();next()})}
function showSetup(){S.quiz=false;stopAnim();clearTimeout(autoT);$('rcQuiz').hidden=true;$('rcSetup').hidden=false;$('rcBack').hidden=true;buildCols();buildPick();sync()}
$('rcStart').onclick=()=>{if(S.sel.size)showQuiz()};
$('rcBack').onclick=showSetup;
$('rcHome').onclick=()=>history.back();

// open on the setup screen every time the category is entered
let was=false;new MutationObserver(()=>{const on=document.body.dataset.v=='pll';if(on&&!was)showSetup();if(!on&&was){stopAnim();clearTimeout(autoT)}was=on}).observe(document.body,{attributes:true,attributeFilter:['data-v']});
setRot();buildCols();buildPick();sync();
})();
