(()=>{
const $=i=>document.getElementById(i),P=(n)=>{try{SFX.play(n)}catch(e){}},G={U:0,D:0,R:1,L:1,F:2,B:2},PZ={'2x2':['URF',11],'3x3':['URFDLB',20],'4x4':['URFDLB',40],'5x5':['URFDLB',60]},
DEF={insp:0,ilen:15,alert:0,hold:300,live:0,dec:3,vib:1,mph:1,keep:0,hide:0,ssz:2,two:0,side:0,bgdim:35,bgblur:0,sfx:0,ui:1,vol:100,diff:1,dark:1},esc=s=>s.replace(/[&<>"]/g,c=>'&#'+c.charCodeAt(0)+';');
let D={set:{...DEF},S:[{n:'Session 1',p:'3x3',t:[]}],c:0},F={S:[{n:'F2L session 1',p:'3x3',t:[]}],c:0},M='t',wl=null,scr='',st='idle',pv='idle',t0=0,hT=0,iI=0,iT=0,pen=0,raf=0,sp=[],al=[0,0],ac=null,np='3x3',blk=0,shown=false,sel=new Set(),lp=0,lpd=0,ex=-1;const pr={L:0,R:0};
try{const x=JSON.parse(localStorage.getItem('x9'));if(x&&x.S&&x.S.length)D={S:x.S,c:Math.min(x.c|0,x.S.length-1),set:{...DEF,...x.set}}}catch(e){}
try{const x=JSON.parse(localStorage.getItem('x9f'));if(x&&x.S&&x.S.length)F={S:x.S,c:Math.min(x.c|0,x.S.length-1)}}catch(e){}
let W={S:[{n:'PLL cases',p:'3x3',t:[]},{n:'OLL cases',p:'3x3',t:[]}],c:0},wc={sub:'',i:0,k:''};
try{const x=JSON.parse(localStorage.getItem('x9w'));if(x&&x.S&&x.S.length==2)W={S:x.S,c:x.c?1:0}}catch(e){}
const CAP0=$('xCap').textContent,wsub=()=>W.c?'oll':'pll';
let sv=0,LT=0,lim=150;const flush=()=>{clearTimeout(sv);sv=0;try{localStorage.setItem('x9',JSON.stringify(D));localStorage.setItem('x9f',JSON.stringify(F));localStorage.setItem('x9w',JSON.stringify(W))}catch(e){}},save=()=>{if(!sv)sv=setTimeout(flush,350)},DS=()=>M=='f'?F:M=='w'?W:D,ses=()=>DS().S[DS().c],V=$('vtimer'),IN=()=>D.set.insp&&!D.set.two;
// views
async function wake(){try{const w=(D.set.keep&&document.body.dataset.v=='timer'||document.body.dataset.v=='vs')&&!document.hidden;if(w&&!wl&&navigator.wakeLock){wl=await navigator.wakeLock.request('screen');wl.onrelease=()=>wl=null}else if(!w&&wl)wl.release()}catch(e){}}
function mode(m){if(m==M)return;M=m;V.dataset.m=m;sel.clear();ex=-1;shown=false;
 document.querySelectorAll('.xnav button').forEach((b,i)=>b.textContent=(m=='w'?['Timer','Good case','Worst case','Records']:['Timer','Times','Graph','Records'])[i]);
 $('xCap').textContent=m=='w'?'White cross + F2L solved · yellow on top':CAP0;opts();gen();render();tab(0)}
const HM=$('vhome').firstElementChild,RM=matchMedia('(prefers-reduced-motion: reduce)').matches;let navBusy=0;
const setV=(v,m,sb)=>{if(v=='vs'){if(document.body.dataset.v!='vs')vsEnter()}else if(document.body.dataset.v=='vs')vsLeave();if(v=='timer'){if(m=='w'){const c=sb=='oll'?1:0;if(M=='w'&&W.c!=c)M='';W.c=c}mode(m||'t')}if(v=='weak')wkPick();if(v=='home')homeReset();document.body.dataset.v=v;document.querySelectorAll('.view').forEach(e=>e.classList.toggle('on',e.id=='v'+v));wake()};
history.replaceState({v:'home'},'');setV('home');
setTimeout(()=>(window.requestIdleCallback||setTimeout)(()=>X9C.init()),3800);
addEventListener('popstate',e=>setV(e.state&&e.state.v||'home',e.state&&e.state.m,e.state&&e.state.s));document.addEventListener('visibilitychange',wake);
function homeReset(){navBusy=0;HM.classList.remove('go');HM.querySelectorAll('.sel,.away').forEach(e=>e.classList.remove('sel','away'));document.querySelectorAll('.hm-burst').forEach(e=>e.remove())}
document.querySelectorAll('[data-go]').forEach(b=>b.onclick=e=>{if(navBusy)return;
 const g=b.dataset.go,v=g=='f2lt'?'timer':g,m=g=='f2lt'?'f':'t',go=()=>{history.pushState({v,m},'');setV(v,m)};
 if(RM){go();return}
 navBusy=1;const r=b.getBoundingClientRect(),x=e.clientX||r.left+r.width/2,y=e.clientY||r.top+r.height/2,W=innerWidth,H=innerHeight,
  far=Math.max(Math.hypot(x,y),Math.hypot(W-x,y),Math.hypot(x,H-y),Math.hypot(W-x,H-y));
 b.style.setProperty('--mx',((x-r.left)/r.width*100).toFixed(0)+'%');b.style.setProperty('--my',((y-r.top)/r.height*100).toFixed(0)+'%');
 HM.classList.add('go');b.classList.add('sel');let k=0;HM.querySelectorAll('.big').forEach(o=>{if(o!=b){o.classList.add('away');o.style.setProperty('--k',k++)}});
 const bu=document.createElement('i');bu.className='hm-burst';bu.style.cssText=`--a:${b.style.getPropertyValue('--a')};--x:${x}px;--y:${y}px;--s:${(far*2/120+1).toFixed(1)}`;document.body.appendChild(bu);setTimeout(()=>bu.remove(),800);
 setTimeout(go,LT?240:300)});
$('xHome').onclick=$('f2lHome').onclick=$('wkHome').onclick=$('hubHome').onclick=()=>history.back();
// F2L hub: Timer or Trainer (opens exactly as before)
document.querySelectorAll('[data-hub]').forEach(b=>b.onclick=()=>{const g=b.dataset.hub,v=g=='f2lt'?'timer':g,m=g=='f2lt'?'f':'t';history.pushState({v,m},'');setV(v,m)});
// Weak Case Mode: choose OLL or PLL, then it opens as a normal timer
function wkPick(){['oll','pll'].forEach((k,j)=>{const n=W.S[j?0:1].t.length;$('wk'+k).textContent=WK.count(k)+' cases · '+n+' solve'+(n==1?'':'s')})}
document.querySelectorAll('[data-sub]').forEach(b=>b.onclick=()=>{const s=b.dataset.sub;history.pushState({v:'timer',m:'w',s},'');setV('timer','w',s)});
// scramble
function gen(){gen0();if(D.set.two==2&&LK.ok&&LK.r=='h')lkSend({e:'scr',s:scr})}
function gen0(){const dd=D.set.diff|0,df=dd==3?X9C.rnd()*3|0:dd;if(M=='w'){wgen();return}if(M=='f'){scr=X9C.z2s(X9C.f2lScramble(df?[0,18,30][df]:6+(X9C.rnd()*7|0)));hint(0);$('xScr').textContent=scr;drawNet();return}
 const pz=ses().p,[m,n0]=PZ[pz],c3=pz=='3x3',n=c3?n0:Math.max(4,Math.round(n0*[.5,1,1.5][df])),w=/[45]/.test(pz[0]);
 const mk=()=>{const o=[];let l='',p='';while(o.length<n){const f=m[X9C.rnd()*m.length|0];if(f==l||(G[f]==G[l]&&G[p]==G[l]))continue;o.push(f+(w&&X9C.rnd()<.35?'w':'')+['',"'",'2'][X9C.rnd()*3|0]);p=l;l=f}return o.join(' ')};
 // 3x3: easy = cross solves in 4 moves or fewer, hard = 7+ moves (optimal), medium = any random scramble
 scr=c3?X9C.pickByCross(df==0?1:df==2?2:0,mk):mk();hint(0);$('xScr').textContent=scr;drawNet()}
// weak case mode: the next case (your slow ones come up more often) with a random turn before and after it
function wgen(){const sub=wsub(),i=WK.pick(sub,ses().t,wc.sub==sub?wc.k:''),a=Math.random()*4|0,b=Math.random()*4|0;
 wc={sub,i,k:WK.list(sub)[i].k};scr=WK.scramble(sub,i,a,b);hint(0);$('xScr').textContent=scr;drawNet()}
// cross hint (light bulb under the eye): optimal white cross for the current 3x3 scramble
function hint(on){const e=$('xHint');e.hidden=!on;$('xHintB').classList.toggle('on',!!on);if(on){const h=X9C.crossHint(scr);e.innerHTML='<small>White cross · flip with z2 first</small><b>'+(h?h.replace(/^z2 /,'<i>z2</i> '):'Already solved')+'</b>'}}
$('xHintB').onclick=()=>{if(st!='idle'&&st!='insp')return;hint($('xHint').hidden?1:0)};
// scrambled cube layout (net) shown at the bottom middle
const SCH={t:{U:'#f5f5f5',D:'#ffd23f',F:'#25c26e',B:'#2f7bff',R:'#ef4444',L:'#ff8a1f'},f:{U:'#f5f5f5',D:'#ffd23f',F:'#25c26e',B:'#2f7bff',R:'#ef4444',L:'#ff8a1f'}};SCH.w={U:'#ffd23f',D:'#f5f5f5',F:'#25c26e',B:'#2f7bff',R:'#ff8a1f',L:'#ef4444'};let netN=0,netR=[];
function drawNet(){const N=+ses().p[0],g=$('xNetS');
 if(N!=netN){const L=X9C.netLayout(N);netN=N;g.setAttribute('viewBox',`-.1 -.1 ${(L.w+.2).toFixed(2)} ${(L.h+.2).toFixed(2)}`);
  g.innerHTML=L.cells.map(c=>`<rect x="${c.x.toFixed(2)}" y="${c.y.toFixed(2)}" width="1" height="1" rx=".1"/>`).join('');netR=[...g.querySelectorAll('rect')]}
 const c=X9C.net(N,scr),k=SCH[M];netR.forEach((r,i)=>r.setAttribute('fill',k[c[i]]))}
// maths
const val=r=>r.p==3?Infinity:r.t+(r.p==2?2000:0);
function fmt(ms){const d=D.set.dec;if(ms==null)return'--';if(!isFinite(ms))return'DNF';const s=ms/1000,m=s/60|0,x=(s-m*60).toFixed(d);return m?m+':'+(x.length<d+3?'0':'')+x:x}
const lab=r=>fmt(val(r))+(r.p==2?'+':''),secs=t=>{const s=t/1000|0;return s>=60?(s/60|0)+':'+('0'+s%60).slice(-2):''+s};
const phs=a=>a.map((t,i)=>`P${i+1} ${fmt(t-(a[i-1]||0))}`).join('  '),phTxt=r=>r.ph&&r.ph.length?phs([...r.ph,r.t]):'';
function ao(a,n){if(a.length<n)return null;const v=a.slice(-n).map(val).sort((x,y)=>x-y),k=Math.ceil(n*.05),m=v.slice(k,n-k);return m.includes(Infinity)?Infinity:m.reduce((x,y)=>x+y)/m.length}
function stats(){const a=ses().t,v=a.map(val).filter(isFinite),mean=v.length?v.reduce((x,y)=>x+y)/v.length:null,best=v.length?Math.min(...v):null,
 sd=v.length?Math.sqrt(v.reduce((s,x)=>s+(x-mean)**2,0)/v.length):null;
 if(M=='w'){$('xL').innerHTML=`Solves: ${a.length}`;$('xRec').innerHTML='';$('xR').innerHTML='';return}
 $('xL').innerHTML=`Best: ${fmt(best)}<br>Mean: ${fmt(mean)}<br>Deviation: ${fmt(sd)}<br>Count: ${a.length}`;
 $('xRec').innerHTML=a.slice(-5).reverse().map(r=>`<span>${lab(r)}</span>`).join('');
 $('xR').innerHTML=[5,12,50,100,1000].map(n=>`Ao${n}: ${fmt(ao(a,n))}`).join('<br>')}
// timer
const cls=c=>{$('xTime').className=c;V.dataset.c=c},disp=t=>$('xTime').textContent=t;
function showLast(){if(LKg()){disp(gl||fmt(0));$('xPh').textContent='';$('xPh').dataset.v='';$('xAct').style.visibility='hidden';return}const r=shown?ses().t.slice(-1)[0]:null;disp(r?lab(r):fmt(0));if(D.set.two==2&&LK.ok&&LK.r=='h')lkSend({e:'r',v:r?lab(r):fmt(0)});const vd=r&&M=='w'&&r.k?WK.verdict(wsub(),ses().t,r):null;$('xPh').textContent=vd?r.k+' · '+vd.t:r?phTxt(r):'';$('xPh').dataset.v=vd?vd.v:'';$('xAct').style.visibility=r?'visible':'hidden';if(r){const q=$('xAct').querySelectorAll('button');q[0].disabled=r.p>=2;q[1].disabled=r.p==3;q[2].disabled=!(r.u&&r.u.length)}}
function beep(f){try{const o=ac.createOscillator(),g=ac.createGain();o.frequency.value=f;g.gain.value=.15;o.connect(g);g.connect(ac.destination);o.start();o.stop(ac.currentTime+.12)}catch(e){}}
function say(s){if(D.set.alert==1)beep(s>8?1100:880);else if(D.set.alert==2&&window.speechSynthesis){speechSynthesis.cancel();speechSynthesis.speak(new SpeechSynthesisUtterance(s+' seconds'))}}
function showI(){const L=D.set.ilen,e=(performance.now()-iT)/1000,d=Math.ceil(L-e);disp(e<L?d:e<L+2?'+2':'DNF');[12,8].forEach((a,n)=>{if(d==a&&e<L&&!al[n]){al[n]=1;say(a)}})}
function insp(){st='insp';al=[0,0];iT=performance.now();cls('insp');try{if(D.set.alert==1){ac=ac||new AudioContext();ac.resume()}}catch(e){}showI();iI=setInterval(showI,50);$('xAct').style.visibility='hidden';$('xPh').textContent=''}
let lt=0,ltx='';function loop(){if(st!='run')return;const n=performance.now(),t=n-t0;if(!LT||n-lt>=33){lt=n;const s=D.set.live==0?fmt(t):D.set.live==1?secs(t):'• • •';if(s!==ltx){ltx=s;disp(s)}}raf=requestAnimationFrame(loop)}
function start(){clearInterval(iI);const L=D.set.ilen,e=pv=='insp'?(performance.now()-iT)/1000:0;pen=pv=='insp'?(e>L+2?3:e>L?2:0):0;
 st='run';ltx='';sp=[];t0=performance.now();cls('');$('xAct').style.visibility='hidden';$('xPh').textContent='';V.classList.add('solving');hint(0);P('start');loop()}
let lastT=0,gl='';function stop(tv){const t=tv!=null?tv:performance.now()-t0;lastT=Math.round(t);
 if(LKg()){cancelAnimationFrame(raf);st='idle';shown=true;V.classList.remove('solving');gl=fmt(lastT);P('stop');disp(gl);return}cancelAnimationFrame(raf);st='idle';shown=true;V.classList.remove('solving');
 const prev=ses().t.map(val).filter(isFinite),nv=pen==3?Infinity:Math.round(t)+(pen==2?2000:0);P(prev.length&&nv<Math.min(...prev)?'pb':'stop');ses().t.push({t:Math.round(t),p:pen,s:scr,d:Date.now(),...(M=='w'?{k:wc.k}:{}),...(sp.length?{ph:sp.slice()}:{})});save();render();opts();setTimeout(()=>{if(!LKg())gen()},30)}
function runTap(){if(D.set.mph>1&&sp.length<D.set.mph-1){sp.push(Math.round(performance.now()-t0));P('split');$('xPh').textContent=phs(sp);return 0}stop();return 1}
function down(){if(st=='run'){runTap();return}
 if(st=='idle'&&IN()){st='tap';return}
 if(st!='idle'&&st!='insp')return;
 pv=st;st='hold';cls('red');P('hold');hT=setTimeout(()=>{if(st=='hold'){st='ready';cls('green');P('ready')}},D.set.hold)}
function up(){clearTimeout(hT);if(st=='tap')return insp();if(st=='ready')return start();if(st=='hold'){st=pv;cls(pv=='insp'?'insp':'');P('cancel')}}
// one-hand: whole screen is the touch area
$('xTab0').addEventListener('pointerdown',e=>{if(!D.set.two&&(st=='run'||!e.target.closest('button')))down()});
$('xTab0').addEventListener('pointerup',()=>{if(!D.set.two)up()});
// two-hand: both pads held = ready, release both = start, touch either = stop
function pd(s){pr[s]=1;$('p'+s).classList.add('d');if(st=='run'){if(runTap())blk=1;return}if(blk)return;if(pr.L&&pr.R)down()}
function pu(s){if(!pr[s])return;pr[s]=0;$('p'+s).classList.remove('d');if(!pr.L&&!pr.R)blk=0;if(blk)return;if(st=='hold'||!pr.L&&!pr.R)up()}
// two phones: each phone has one pad; presses are mirrored to the other phone over the link
const mine=()=>D.set.side==1?'R':'L',LK={ok:0,r:'h',pc:null,dc:null,long:0},LKg=()=>D.set.two==2&&LK.ok&&LK.r=='g';
function lkSend(m){try{if(LK.ok&&LK.dc&&LK.dc.readyState=='open')LK.dc.send(JSON.stringify(m))}catch(e){}}
function padLbl(){['L','R'].forEach(k=>{const e=$('p'+k);if(e)e.textContent=D.set.two==2&&!LK.ok&&k==mine()?'TAP TO LINK':'HOLD'})}
function lkMsg(m){if(m.e=='d')pd(m.s);else if(m.e=='u')pu(m.s);
 else if(m.e=='x'){if(LK.r=='g'){gl=fmt(m.t);if(st=='idle')disp(gl)}else{const r=ses().t.slice(-1)[0];if(r&&shown&&st=='idle'&&Math.abs(r.t-m.t)<3000){r.t=m.t;save();render();opts()}}}
 else if(m.e=='r'&&LK.r=='g'){gl=m.v;if(st=='idle')disp(gl)}
 else if(m.e=='scr'&&LK.r=='g'){scr=m.s;hint(0);$('xScr').textContent=scr;drawNet()}
 else if(m.e=='new'&&LK.r=='h')gen()}
for(const s of['L','R']){const el=$('p'+s);
 el.addEventListener('pointerdown',()=>{if(D.set.two!=2){pd(s);return}if(!LK.ok){lkOpen();return}if(s!=mine())return;const was=st=='run';pd(s);lkSend({e:'d',s});if(was&&st!='run')lkSend({e:'x',t:lastT})});
 const rel=()=>{if(D.set.two==2&&(!LK.ok||s!=mine()))return;pu(s);if(D.set.two==2)lkSend({e:'u',s})};
 el.addEventListener('pointerup',rel);el.addEventListener('pointercancel',rel)}
// link: direct phone-to-phone connection (WebRTC); the two codes are swapped by hand, no server needed
// Phones on different networks (mobile data vs wifi, CGNAT) often can't connect directly and need a TURN relay.
// The free public relay below is best-effort; for reliable play across networks put your own TURN server here (username/credential from e.g. metered.ca or Cloudflare).
const ICE={iceServers:[{urls:['stun:stun.l.google.com:19302','stun:stun.cloudflare.com:3478']},{urls:['turn:openrelay.metered.ca:80','turn:openrelay.metered.ca:443','turn:openrelay.metered.ca:443?transport=tcp'],username:'openrelayproject',credential:'openrelayproject'}]};
// short code: only what the other phone needs (ICE login, DTLS fingerprint, address), rebuilt into a normal SDP on the other side
function sdpPack(d){const x=d.sdp,g=r=>(x.match(r)||[])[1],u=g(/a=ice-ufrag:(\S+)/),p=g(/a=ice-pwd:(\S+)/),f=g(/a=fingerprint:sha-256 (\S+)/),su=['actpass','active','passive'].indexOf(g(/a=setup:(\S+)/));
 if(!u||!p||!f||su<0)throw 0;const fb=btoa(String.fromCharCode(...f.split(':').map(h=>parseInt(h,16)))).replace(/=+$/,''),
 c=[...x.matchAll(/a=candidate:\S+ 1 udp \d+ (\S+) (\d+) typ (host|srflx)/g)].map(m=>(m[3]=='host'?'h':'s')+m[1]+'|'+m[2]).sort((i,j)=>(j[0]=='h')-(i[0]=='h')).slice(0,3);
 if(!c.length)throw 0;return 'x9~'+(d.type=='offer'?'o':'a')+su+'~'+u+'~'+p+'~'+fb+'~'+c.join(',')}
function sdpUnpack(code){const a=code.replace(/\s/g,'').split('~');if(a[0]!='x9'||a.length<6)throw 0;
 const fp=[...atob(a[4])].map(c=>('0'+c.charCodeAt(0).toString(16)).slice(-2).toUpperCase()).join(':'),
 cs=a[5].split(',').filter(Boolean).map((x,i)=>{const k=x.lastIndexOf('|');return `a=candidate:${i+1} 1 udp ${2113937151-i*1000} ${x.slice(1,k)} ${x.slice(k+1)} typ ${x[0]=='h'?'host':'srflx raddr 0.0.0.0 rport 0'}`});
 return{type:a[1][0]=='o'?'offer':'answer',sdp:['v=0','o=- 1 2 IN IP4 127.0.0.1','s=-','t=0 0','a=group:BUNDLE 0','m=application 9 UDP/DTLS/SCTP webrtc-datachannel','c=IN IP4 0.0.0.0','a=ice-ufrag:'+a[2],'a=ice-pwd:'+a[3],'a=fingerprint:sha-256 '+fp,'a=setup:'+['actpass','active','passive'][+a[1][1]],'a=mid:0','a=sctp-port:5000',...cs].join('\r\n')+'\r\n'}}
const lkEnc=d=>{const L=d.sdp.split('\r\n'),mk=()=>btoa(JSON.stringify({type:d.type,sdp:L.join('\r\n')}));let c=mk();for(let i=L.length-1;c.length>3600&&i>=0;i--)if(/^a=candidate:.* tcp .* typ (host|relay)/.test(L[i])){L.splice(i,1);c=mk()}return c},
 lkDec=t=>{const c=t.replace(/\s/g,'');if(c.startsWith('x9~')){LK.long=0;return sdpUnpack(c)}LK.long=1;return JSON.parse(atob(c))};
function lkState(t){const a=$('lkMsg');if(a)a.textContent=t;const b=$('lkSt');if(b)b.textContent=LK.ok?'Connected':'Not connected';const o=$('lkOpen');if(o)o.textContent=LK.ok?'Relink':'Link';padLbl()}
function lkClose(){clearInterval(LK.hb);const pc=LK.pc,dc=LK.dc,bye=LK.ok;LK.ok=0;LK.pc=LK.dc=null;try{if(dc){dc.onclose=null;if(bye&&dc.readyState=='open')dc.send('{"e":"bye"}')}}catch(e){}setTimeout(()=>{try{dc&&dc.close();pc&&pc.close()}catch(e){}},bye?300:0);pr.L=pr.R=0;['pL','pR'].forEach(i=>$(i).classList.remove('d'));lkState('Not connected')}
// other side went away (closed, crashed, out of range): free this phone and show the link screen with a way out
function lkDrop(msg){if(!LK.ok&&!LK.pc)return;const was=LK.ok;LK.ok=0;lkClose();gl='';if(VS.on)vsLost();else if(st=='idle')showLast();if(was){lkOpen();lkState(msg)}else lkState(msg)}
function lkWire(dc){LK.dc=dc;dc.onopen=()=>{LK.ok=1;lkState('Connected ✓');P('on');if(VS.on)vsOpen();else if(LK.r=='h'){lkSend({e:'scr',s:scr});if(st=='idle')showLast()}else gl='';setTimeout(()=>$('dL').classList.remove('on'),900);LK.seen=Date.now();lkSend({e:'p',t:performance.now()});clearInterval(LK.hb);LK.hb=setInterval(()=>{if(!LK.ok||LK.dc!==dc){clearInterval(LK.hb);return}lkSend({e:'p',t:performance.now()});if(Date.now()-LK.seen>10000)lkDrop(LK.r=='g'?'Host disconnected.':'Other phone disconnected.')},2000)};
 dc.onclose=()=>{if(LK.dc===dc)lkDrop(LK.r=='g'?'Host disconnected.':'Other phone disconnected.')};dc.onmessage=e=>{try{const m=JSON.parse(e.data);LK.seen=Date.now();if(m.e=='p'){lkSend({e:'q',t:m.t});return}if(m.e=='q'){const r=performance.now()-m.t;LK.rtt=LK.rtt?LK.rtt*.6+r*.4:r;return}if(m.vs){vsMsg(m);return}if(m.e=='bye'){lkDrop(LK.r=='g'?'Host disconnected.':'Other phone disconnected.');return}lkMsg(m)}catch(_){}}}
function lkNew(){lkClose();LK.rtt=0;const pc=LK.pc=new RTCPeerConnection(ICE);pc.onconnectionstatechange=()=>{if(LK.pc===pc&&LK.ok&&/failed|closed/.test(pc.connectionState))lkDrop('Link lost.')};return pc}
const lkWait=pc=>new Promise(ok=>{if(pc.iceGatheringState=='complete')return ok();const f=()=>{if(pc.iceGatheringState=='complete'){pc.removeEventListener('icegatheringstatechange',f);ok()}};pc.addEventListener('icegatheringstatechange',f);setTimeout(ok,4500)});
function lkOpen(){LK.busy=0;$('lkRole').hidden=false;$('lkH').hidden=$('lkG').hidden=true;['lkO1','lkI2'].forEach(i=>$(i).value='');lkState(LK.ok?'Connected. Pick one to relink.':'Is this the host or the other pad?');$('dL').classList.add('on');P('pop')}
// signaling: the short room code is the only thing typed; the offer/answer travel through a free public relay (ntfy.sh)
const SIG='https://ntfy.sh/x9t-',RA='ABCDEFGHJKLMNPQRSTUVWXYZ23456789',sleep=t=>new Promise(r=>setTimeout(r,t));
const sigPut=(room,txt)=>fetch(SIG+room,{method:'POST',body:txt}).then(r=>{if(!r.ok)throw 0});
async function sigGet(room,pre){const r=await fetch(SIG+room+'/json?poll=1&since=all'),t=await r.text(),o=[];for(const l of t.split('\n')){try{const m=JSON.parse(l);if(m.event=='message'&&typeof m.message=='string'&&m.message[0]==pre)o.push(m.message.slice(1))}catch(_){}}return o}
async function lkHost(){const tok=LK.tok=Date.now();try{lkState('Making code…');const pc=lkNew(),dc=pc.createDataChannel('x9');lkWire(dc);await pc.setLocalDescription(await pc.createOffer());await lkWait(pc);if(LK.pc!==pc)return;
 const room=Array.from(crypto.getRandomValues(new Uint8Array(6)),x=>RA[x%32]).join('');await sigPut(room,'o'+lkEnc(pc.localDescription).replace(/\s/g,''));if(LK.pc!==pc)return;
 $('lkO1').value=room;lkState('Tell the other phone this code. It connects by itself.');
 for(let i=0;i<150&&LK.pc===pc&&!LK.ok;i++){await sleep(2000);if(LK.pc!==pc||LK.ok||pc.signalingState!='have-local-offer')continue;let a;try{a=await sigGet(room,'a')}catch(_){continue}if(a.length){await pc.setRemoteDescription(lkDec(a[a.length-1]));lkState('Connecting…');return}}
 if(LK.pc===pc&&!LK.ok)lkState('No one joined. Tap Host again for a new code.')}catch(e){lkState('Could not make a code. Check your internet.')}}
async function lkJoin(){const room=$('lkI2').value.replace(/[^A-Za-z0-9]/g,'').toUpperCase();if(room.length!=6||LK.busy)return;LK.busy=1;
 try{const pc=lkNew();pc.ondatachannel=e=>lkWire(e.channel);lkState('Finding host…');let o=[];for(let i=0;i<8&&!o.length;i++){try{o=await sigGet(room,'o')}catch(_){}if(!o.length)await sleep(1500)}
  if(!o.length){lkState('Host code not found. Check it and paste again.');return}
  await pc.setRemoteDescription(lkDec(o[o.length-1]));await pc.setLocalDescription(await pc.createAnswer());await lkWait(pc);if(LK.pc!==pc)return;
  await sigPut(room,'a'+lkEnc(pc.localDescription).replace(/\s/g,''));lkState('Connecting…')}catch(e){lkState('Could not connect. Check the code and your internet.')}finally{LK.busy=0}}
$('lkRole').onclick=e=>{const b=e.target.closest('[data-r]');if(!b)return;LK.r=b.dataset.r;D.set.side=LK.r=='g'?1:0;save();lay();$('lkRole').hidden=true;$(LK.r=='h'?'lkH':'lkG').hidden=false;if(LK.r=='h')lkHost();else{lkState('Enter the host’s code.');$('lkJoinGo').disabled=true;$('lkI2').focus()}};
const lkCode=()=>$('lkI2').value.replace(/[^A-Za-z0-9]/g,'').toUpperCase();
$('lkI2').oninput=()=>{const c=lkCode();$('lkJoinGo').disabled=c.length!=6;if(c.length==6)lkState('Check the code, then tap Join.')};
$('lkI2').onkeydown=e=>{if(e.key=='Enter'){e.preventDefault();$('lkJoinGo').click()}};
$('lkJoinGo').onclick=()=>{if(lkCode().length==6)lkJoin()};
// ---- 1v1 battle: same scramble on two phones, best of 3/5/7 ----
// both players hold their own pad until it turns green; when both are green and both let go, both timers start; each player stops on their own
const VS={overT:0,oN:'',mRm:0,oRm:0,on:0,bo:3,h:0,g:0,rd:1,scr:'',ph:'lobby',mR:0,oR:0,mUp:0,oUp:0,mT:null,oT:null,t0:0,raf:0,hT:0,nx:0,res:'',last:null};
const vsH=()=>LK.r=='h',vsNeed=()=>Math.ceil(VS.bo/2);
function vsScr(){const dd=D.set.diff|0,df=dd==3?Math.random()*3|0:dd,m='URFDLB',mk=()=>{const o=[];let l='',p='';while(o.length<20){const f=m[Math.random()*6|0];if(f==l||(G[f]==G[l]&&G[p]==G[l]))continue;o.push(f+['',"'",'2'][Math.random()*3|0]);p=l;l=f}return o.join(' ')};return X9C.pickByCross(df==0?1:df==2?2:0,mk)}
const vsNm=()=>(D.set.name||'').trim().slice(0,14)||'Player',vsON=()=>VS.oN||'Opponent',vsClean=t=>String(t||'').replace(/[\u0000-\u001f<>]/g,'').trim().slice(0,14);
function vsClear(){clearTimeout(VS.hT);clearTimeout(VS.nx);cancelAnimationFrame(VS.raf)}
const DLH=$('dL').parentNode,DLN=$('dL').nextSibling;
function vsEnter(){VS.on=1;document.body.appendChild($('dL'));lkClose();vsClear();Object.assign(VS,{oN:'',mRm:0,oRm:0,ph:'lobby',h:0,g:0,rd:1,scr:'',res:'',mR:0,oR:0,mUp:0,oUp:0,mT:null,oT:null,last:null});LK.r='h';$('vsName').value=D.set.name||'';vsUI()}
function vsLeave(){VS.on=0;vsClear();lkClose();$('dL').classList.remove('on');DLH.insertBefore($('dL'),DLN&&DLN.parentNode==DLH?DLN:null)}
function vsRole(r){lkOpen();const b=$('lkRole').querySelector('[data-r="'+r+'"]');if(b)b.click()}
function vsOpen(){VS.ph='lobby';vsClear();lkSend({vs:'hi',n:vsNm()});if(vsH())lkSend({vs:'cfg',bo:VS.bo});vsUI()}
function vsLost(){vsClear();VS.ph='lobby';VS.res='';VS.oN='';vsUI()}
function vsRound(){vsClear();VS.ph='idle';VS.mR=VS.oR=VS.mUp=VS.oUp=0;VS.mT=VS.oT=null;VS.last=null;VS.res='';VS.mRm=VS.oRm=0;vsUI()}
function vsStart(){if(!LK.ok||!vsH())return;VS.h=VS.g=0;VS.rd=1;VS.scr=vsScr();vsRound();lkSend({vs:'n',scr:VS.scr,rd:1,h:0,g:0,bo:VS.bo})}
function vsNext(){if(!LK.ok||!vsH())return;const l=VS.last;VS.scr=vsScr();if(l)VS.rd++;vsRound();lkSend({vs:'n',scr:VS.scr,rd:VS.rd,h:VS.h,g:VS.g,bo:VS.bo})}
function vsPress(){if(VS.ph!='idle'||!LK.ok)return;VS.ph='hold';P('hold');vsUI();clearTimeout(VS.hT);VS.hT=setTimeout(()=>{if(VS.ph=='hold'){VS.ph='ready';VS.mR=1;P('ready');lkSend({vs:'r',v:1});vsChk();vsUI()}},D.set.hold)}
function vsRel(){clearTimeout(VS.hT);
 if(VS.ph=='hold'){VS.ph='idle';P('cancel')}
 else if(VS.ph=='ready'){VS.ph='idle';VS.mR=0;lkSend({vs:'r',v:0});P('cancel')}
 vsUI()}
// both holding and green -> the host starts a 5 second countdown; both timers start by themselves when it ends (no release needed)
function vsChk(){if(VS.ph=='ready'&&VS.oR&&vsH())vsCount(0)}
function vsCount(off){VS.ph='count';VS.res='';VS.cdN=0;VS.cdEnd=performance.now()+5000-off;if(vsH())lkSend({vs:'cd'});cancelAnimationFrame(VS.raf);vsCd()}
function vsCd(){if(VS.ph!='count')return;const rem=VS.cdEnd-performance.now();
 if(rem<=0){VS.ph='run';VS.t0=VS.cdEnd;VS.mT=null;SFX.play('vgo',true,3);vsLoop();vsUI();return}
 const n=Math.ceil(rem/1000);if(n!=VS.cdN){VS.cdN=n;SFX.play('vtick',true,3);vsUI()}VS.raf=requestAnimationFrame(vsCd)}
function vsLoop(){if(VS.ph!='run')return;const t=performance.now()-VS.t0,l=D.set.live;$('vsMt').textContent=l==0?fmt(t):l==1?secs(t):'• • •';VS.raf=requestAnimationFrame(vsLoop)}
function vsStop(){if(VS.ph!='run')return;const t=Math.round(performance.now()-VS.t0);cancelAnimationFrame(VS.raf);VS.mT=t;VS.ph='fin';P('stop');lkSend({vs:'f',t});vsUI();vsDone()}
function vsDone(){if(VS.ph!='fin'||VS.mT==null||VS.oT==null)return;const me=VS.mT,op=VS.oT,H=vsH();let w=null;if(me<op)w=H?'h':'g';else if(op<me)w=H?'g':'h';
 if(w)VS[w]++;VS.last=w;VS.res=w?(w==LK.r?'You win the round':vsON()+' wins the round'):'Tie. This round replays';const fin=w&&VS[w]>=vsNeed();P(!w?'vtick':w==LK.r?(fin?'vwin':'vpoint'):(fin?'vlose':'vloss'));
 if(fin){VS.ph='between';VS.res=w==LK.r?'You win the match!':vsON()+' wins the match';VS.nx=setTimeout(()=>{if(VS.ph=='between'){VS.ph='over';VS.overT=performance.now();vsUI()}},2000)}else{VS.ph='between';if(H)VS.nx=setTimeout(vsNext,2800)}vsUI()}
function vsMsg(m){if(!VS.on)return;
 if(m.vs=='hi'){VS.oN=vsClean(m.n);vsUI()}
 else if(m.vs=='cfg'){VS.bo=m.bo;vsUI()}
 else if(m.vs=='r'){VS.oR=m.v;if(!m.v){if(VS.ph=='count'){cancelAnimationFrame(VS.raf);VS.ph='ready';VS.res=vsON()+' let go. Countdown cancelled'}}else vsChk();vsUI()}
 else if(m.vs=='cd'){VS.oR=1;if(VS.ph=='ready')vsCount(Math.round((LK.rtt||0)/2))}
 else if(m.vs=='f'){VS.oT=m.t;vsUI();vsDone()}
 else if(m.vs=='n'){VS.scr=m.scr;VS.rd=m.rd;VS.h=m.h;VS.g=m.g;VS.bo=m.bo;vsRound();P('pop')}
 else if(m.vs=='rm'){VS.oRm=1;if(vsH()&&VS.mRm)vsStart();else vsUI()}}
function vsUI(){const ph=VS.ph,g=ph!='lobby',H=vsH(),me=H?VS.h:VS.g,op=H?VS.g:VS.h;
 $('vsLobby').hidden=g;$('vsGame').hidden=!g;$('vsInfo').textContent='1v1 · Best of '+VS.bo;$('vsEnd').hidden=ph!='over';
 document.querySelectorAll('#vsBo [data-bo]').forEach(b=>{b.classList.toggle('on',+b.dataset.bo==VS.bo);b.disabled=LK.ok&&!H||ph!='lobby'&&g});
 $('vsGo').hidden=!(LK.ok&&H);$('vsRoles').hidden=!!LK.ok;
 $('vsSt').textContent=!LK.ok?'Is this phone the host or joining?':H?'Connected to '+vsON()+'. Pick the format, then start.':'Connected to '+vsON()+'. Waiting for the host to start…';
 if(!g)return;
 $('vsN1').textContent=$('vsN2').textContent=vsNm();$('vsO1').textContent=$('vsO2').textContent=vsON();$('vsMe').textContent=me;$('vsOp').textContent=op;$('vsRd').textContent='Round '+VS.rd+' · first to '+vsNeed();$('vsScr').textContent=VS.scr;
 if(ph!='run')$('vsMt').textContent=VS.mT!=null?fmt(VS.mT):fmt(0);
 $('vsOt').textContent=VS.oT!=null?fmt(VS.oT):(ph=='run'||ph=='fin')?'Racing…':VS.oR?'Ready':'--';
 const T={idle:['Hold your pad down','HOLD'],hold:['Keep holding…','HOLD'],ready:[VS.res||'Ready. Waiting for opponent…','READY'],count:['Starts at zero. You can let go now',String(VS.cdN)],run:['Tap anywhere to stop','STOP'],fin:['Waiting for opponent to finish…','DONE'],between:[VS.res,'NEXT ROUND SOON'],over:[VS.res,'']}[ph]||['',''];
 $('vsMsg').textContent=ph=='idle'&&VS.res?VS.res:T[0];$('vsPad').textContent=T[1];
 $('vvs').dataset.c=ph=='hold'?'red':ph=='ready'||ph=='count'?'green':'';$('vvs').dataset.p=ph;
 if(ph=='over'){const w=me>op;$('vsEndT').textContent=w?'YOU WIN':'YOU LOSE';$('vsEndS').textContent=vsNm()+' '+me+' – '+op+' '+vsON();$('vsEndT').dataset.w=w?1:0;$('vsEndN').textContent=VS.mRm?'Waiting for '+vsON()+'…':VS.oRm?vsON()+' wants a rematch':'';$('vsRm').textContent=VS.oRm&&!VS.mRm?'Accept rematch':'Rematch';$('vsRm').disabled=!!VS.mRm}}
{const pad=$('vsPad');pad.addEventListener('pointerdown',e=>{e.preventDefault();vsPress()});pad.addEventListener('pointerup',vsRel);pad.addEventListener('pointercancel',vsRel);pad.addEventListener('contextmenu',e=>e.preventDefault())}
$('vsGame').addEventListener('pointerdown',()=>{if(VS.ph=='run')vsStop()});
$('vsHome').onclick=()=>history.back();$('vsHost').onclick=()=>vsRole('h');$('vsJoin').onclick=()=>vsRole('g');$('vsGo').onclick=vsStart;
$('vsBo').onclick=e=>{const b=e.target.closest('[data-bo]');if(!b||b.disabled||!vsH()||VS.ph!='lobby')return;VS.bo=+b.dataset.bo;lkSend({vs:'cfg',bo:VS.bo});vsUI()};
$('vsRm').onclick=()=>{if(VS.mRm||!LK.ok||performance.now()-VS.overT<700)return;VS.mRm=1;lkSend({vs:'rm'});if(vsH()&&VS.oRm)vsStart();else vsUI()};
$('vsName').oninput=()=>{D.set.name=vsClean($('vsName').value);save();if(LK.ok)lkSend({vs:'hi',n:vsNm()})};
$('vsLv').onclick=()=>{if(performance.now()-VS.overT<700)return;history.back()};
$('dL').onclick=e=>{const c=e.target.closest('[data-c]');if(c){const el=$(c.dataset.c);if(!el.value)return;el.select();try{navigator.clipboard.writeText(el.value)}catch(_){try{document.execCommand('copy')}catch(__){}}c.textContent='Copied ✓';return}
 if(e.target.id=='lkX')$('dL').classList.remove('on')};
addEventListener('keydown',e=>{if(document.body.dataset.v!='timer'||e.code!='Space'||e.repeat||document.querySelector('.dlg.on')||/INPUT|SELECT|BUTTON/.test(e.target.tagName)||!$('xTab0').classList.contains('on')||$('xS').classList.contains('on'))return;e.preventDefault();down()});
addEventListener('keyup',e=>{if(e.code=='Space'&&document.body.dataset.v=='timer')up()});
$('xNew').onclick=()=>{if(st=='insp'){clearInterval(iI);st='idle';cls('');showLast()}if(LKg()){lkSend({e:'new'});return}gen()};
$('xBulb').onclick=()=>{if(D.set.two)return;D.set.insp^=1;apply('insp');P(D.set.insp?'on':'off')};
// own confirm dialog (lives inside the timer, so it turns with the two-hand layout; settings use the upright one)
function ask(el,title,txt,ok,one){return new Promise(res=>{el.querySelector('b').textContent=title;el.querySelector('p').textContent=txt;el.querySelector('.ok').textContent=ok;el.querySelector('[data-d="0"]').style.display=one?'none':'';el.classList.add('on');P('pop');
 el.onclick=e=>{const b=e.target.closest('[data-d]');if(!b&&e.target!==el)return;el.classList.remove('on');el.onclick=null;res(!!b&&b.dataset.d=='1')}})}
// results
function act(a){const t=ses().t,r=t[t.length-1];if(!shown||!r)return;
 if(a=='x'){ask($('dT'),'Remove this solve?','This time will be deleted and the timer goes back to 0.000.','Remove').then(y=>{if(y&&shown&&t[t.length-1]===r){P('del');t.pop();shown=false;save();render();opts()}});return}
 else if(a=='u'){if(!(r.u&&r.u.length))return;r.p=r.u.pop();if(!r.u.length)delete r.u;P('undo')}
 else if(a=='2'&&r.p==0||a=='3'&&r.p<3){(r.u=r.u||[]).push(r.p);r.p=a=='2'?2:3;P(a=='2'?'plus2':'dnf')}
 else return;save();render();opts()}
$('xAct').onclick=e=>{const b=e.target.closest('button');if(b&&!b.disabled)act(b.dataset.a)};
function pick(i){sel.has(i)?sel.delete(i):sel.add(i);list()}
const DF=new Intl.DateTimeFormat();
function list(){const a=ses().t;$('xTrash').disabled=!sel.size;$('xAll').disabled=!a.length;$('xAll').textContent=a.length&&sel.size==a.length?'Deselect all':'Select all';let h='';
 if(!a.length)h='<p class="m">No solves yet</p>';
 else{h='<p class="m hint">Tap a time for its scramble · hold to select'+(M=='w'?' · deleting also updates Good / Worst case':'')+'</p>';const lo=Math.max(0,a.length-lim);
  for(let i=a.length-1;i>=lo;i--){const r=a[i],p=phTxt(r);h+=`<div class="rw${sel.has(i)?' sel':''}" data-i="${i}"><span>${i+1}</span>${M=='w'?`<div><b>${lab(r)}</b><small class="wcn">${esc(r.k||'')}</small></div>`:`<b>${lab(r)}</b>`}<span>${DF.format(new Date(r.d))}</span>${p?`<div class="pl">${p}</div>`:''}${ex==i?`<div class="sc">${r.s?esc(r.s):'No scramble saved for this solve'}</div>`:''}</div>`}
  if(lo>0)h+=`<button class="pill more" id="xMore" type="button">Show older (${lo})</button>`}
 $('xList').innerHTML=h}
const lpx=()=>{clearTimeout(lp);setTimeout(()=>lpd=0,80)};
$('xList').addEventListener('pointerdown',e=>{const r=e.target.closest('.rw');if(!r)return;lpd=0;clearTimeout(lp);lp=setTimeout(()=>{lpd=1;P('pick');pick(+r.dataset.i)},450)});
['pointerup','pointercancel','pointerleave'].forEach(n=>$('xList').addEventListener(n,lpx));
$('xList').addEventListener('click',e=>{if(e.target.closest('#xMore')){lim+=150;list();return}const r=e.target.closest('.rw');if(!r)return;if(lpd)return;const i=+r.dataset.i;if(sel.size)pick(i);else{ex=ex==i?-1:i;list()}});
$('xList').oncontextmenu=e=>e.preventDefault();
$('xAll').onclick=()=>{const a=ses().t;if(!a.length)return;if(sel.size==a.length)sel.clear();else{sel.clear();a.forEach((_,i)=>sel.add(i))}ex=-1;list()};
$('xTrash').onclick=()=>{const n=sel.size;if(n)ask($('dT'),n>1?'Delete '+n+' solves?':'Delete this solve?','They will be removed from this session.','Delete').then(y=>{if(y){P('del');ses().t=ses().t.filter((_,i)=>!sel.has(i));sel.clear();ex=-1;shown=false;save();render();opts()}})};
function graph(){const a=ses().t.slice(-50),v=a.map(val),f=v.filter(isFinite),g=$('xGraph');
 if(f.length<2){g.innerHTML='<text x="160" y="100" text-anchor="middle" fill="#888" font-size="12">Need at least 2 solves</text>';return}
 const mx=Math.max(...f),mn=Math.min(...f),n=v.length,x=i=>14+i*292/(n-1),y=t=>180-(t-mn)/(mx-mn||1)*150,
 L=(p,c,w)=>`<polyline points="${p.map(s=>s.join()).join(' ')}" fill="none" stroke="${c}" stroke-width="${w}" stroke-linejoin="round"/>`,
 p=v.map((t,i)=>isFinite(t)&&[x(i),y(t)]).filter(Boolean),q=a.map((_,i)=>{if(i<4)return 0;const m=ao(a.slice(0,i+1),5);return isFinite(m)&&[x(i),y(m)]}).filter(Boolean);
 g.innerHTML=L(p,'#6f6f6f',1.5)+p.map(s=>`<circle cx="${s[0]}" cy="${s[1]}" r="2.2" fill="#9a9a9a"/>`).join('')+L(q,'currentColor',2.2)+`<text x="14" y="12" fill="#888" font-size="9">${fmt(mx)}</text><text x="14" y="196" fill="#888" font-size="9">${fmt(mn)}</text><text x="306" y="12" text-anchor="end" fill="currentColor" font-size="9">— Ao5</text>`}
function wkTab(n){const sub=wsub(),r=WK.split(sub,ses().t),L=n==1?r.good:r.worst;
 let h=`<p class="m hint">${n==1?'Cases you execute well':'Your slowest cases · they come up more often'} · ${r.rated}/${r.total} rated</p>`;
 if(!L.length)h+=`<p class="m">${r.rated?'Nothing here yet':'Solve a case '+WK.MINN+' times to rate it'}</p>`;
 else h+=L.slice(0,15).map(x=>`<div class="wkr ${n==1?'g':'w'}">${WK.mini(sub,x.i)}<div><b>${x.k}</b><small>${x.n} solves · best ${fmt(x.best)}${x.dnf?' · '+x.dnf+' DNF':''}</small></div><strong>${fmt(x.score)}</strong></div>`).join('');
 $('xWk'+n).innerHTML=h}
function tab(n){sel.clear();ex=-1;const w=M=='w',rc=w&&n==3;V.classList.toggle('wrec',rc);document.querySelectorAll('.tab').forEach((e,i)=>e.classList.toggle('on',i==(rc?1:n)));document.querySelectorAll('.xnav button').forEach((e,i)=>e.classList.toggle('on',i==n));if(rc){lim=150;list()}else if(n&&w)wkTab(n);else{if(n==1){lim=150;list()}if(n==2)graph()}}
document.querySelectorAll('.xnav button').forEach((b,i)=>b.onclick=()=>tab(i));
// session dropdown
const pop=$('xSP'),popOpen=o=>{pop.classList.toggle('on',o);$('xSel').setAttribute('aria-expanded',o);if(!o)$('xNI').classList.remove('on')};
function opts(){$('xSL').innerHTML=DS().S.map((x,i)=>`<button class="si${i==DS().c?' on':''}" data-i="${i}"><span>${esc(x.n)}<small>${x.p} · ${x.t.length} solves</small></span></button>`).join('')}
$('xSel').onclick=()=>popOpen(!pop.classList.contains('on'));
V.addEventListener('pointerdown',e=>{if(pop.classList.contains('on')&&!e.target.closest('#xSP,#xSel')){popOpen(0);e.stopPropagation()}},true);
pop.onclick=e=>{const si=e.target.closest('.si'),pc=e.target.closest('[data-p]');
 if(si&&si.id=='xAdd')$('xNI').classList.toggle('on');
 else if(si){DS().c=+si.dataset.i;sel.clear();ex=-1;shown=false;save();popOpen(0);opts();gen();render()}
 else if(pc){np=pc.dataset.p;pop.querySelectorAll('[data-p]').forEach(b=>b.classList.toggle('on',b==pc))}
 else if(e.target.id=='xMk'){const n=$('xNn').value.trim().slice(0,24)||(M=='f'?'F2L session ':'Session ')+(DS().S.length+1);DS().S.push({n,p:M=='f'?'3x3':np,t:[]});DS().c=DS().S.length-1;sel.clear();ex=-1;shown=false;$('xNn').value='';save();popOpen(0);opts();gen();render()}};
function render(){$('xHintB').style.display=(M=='t'&&ses().p=='3x3')?'':'none';$('xPz').textContent=M=='f'?'F2L Timer':M=='w'?'Weak Case · '+(W.c?'OLL':'PLL'):ses().p+' Cube';$('xSn').textContent=ses().n;stats();if(st=='idle')showLast();
 if($('xTab1').classList.contains('on'))M=='w'&&!V.classList.contains('wrec')?wkTab(1):list();if($('xTab2').classList.contains('on'))M=='w'?wkTab(2):graph()}
// settings
const SP=[['Timer'],['two','Two-hand timer','d',[[0,'Off'],[1,'1 phone'],[2,'2 phones']]],['link','Phone link','k'],['hold','Hold time','d',[[0,'None'],[300,'0.3 s'],[550,'0.55 s'],[1000,'1 s']]],['mph','Multiphase','d',[[1,'Off'],[2,'2 phases'],[3,'3 phases'],[4,'4 phases'],[5,'5 phases']]],['live','While solving','d',[[0,'Show decimals'],[1,'Seconds only'],[2,"Don't show time"]]],['hide','Hide UI while solving','t'],
['Inspection'],['insp','Inspection time','t'],['ilen','Inspection length','d',[[5,'5 s'],[10,'10 s'],[15,'15 s (WCA)'],[20,'20 s'],[30,'30 s']]],['alert','Inspection alert (8 s / 12 s)','d',[[0,'Off'],[1,'Beep'],[2,'Voice']]],
['Scramble'],['diff','Scramble difficulty','d',[[0,'Easy (short cross)'],[1,'Medium (normal)'],[2,'Hard (long cross)'],[3,'Off (random)']]],
['Display'],['dec','Decimals','d',[[2,'2'],[3,'3']]],['ssz','Scramble size','d',[[1,'Small'],[2,'Medium'],[3,'Large']]],
['Appearance'],['dark','Dark mode','t'],['bg','Background image / video','b'],['bgdim','Background dim','d',[[0,'None'],[20,'20%'],[35,'35%'],[50,'50%'],[70,'70%']]],['bgblur','Background blur','d',[[0,'Off'],[4,'Light'],[10,'Medium'],[20,'Strong']]],
['General'],['keep','Keep screen on','t']],txt=(o,v)=>(o.find(x=>x[0]==v)||o[0])[1];
function buildS(){$('xBody').innerHTML=SP.map(s=>s.length==1?`<div class="sg">${s[0]}</div>`:s[2]=='k'?(D.set.two==2?`<div class="sr bgr"><span class="bgt">${s[1]}<small id="lkSt">${LK.ok?'Connected':'Not connected'}</small></span><span class="bgb"><button class="pill tiny" id="lkOpen">${LK.ok?'Relink':'Link'}</button></span></div>`:''):s[2]=='b'?`<div class="sr bgr"><span class="bgp" id="bgPv"></span><span class="bgt">${s[1]}<small id="bgSt">${bgHas()?(document.body.classList.contains('hasvid')?'Custom video':'Custom image'):'None'}</small></span><span class="bgb"><button class="pill tiny" id="bgPick">Choose</button><button class="pill tiny" id="bgClr"${bgHas()?'':' disabled'}>Remove</button></span></div>`:s[2]=='t'?`<div class="sr"><span>${s[1]}</span><button class="sw${D.set[s[0]]?' on':''}" data-k="${s[0]}" role="switch" aria-checked="${!!D.set[s[0]]}" aria-label="${s[1]}"><i></i></button></div>`:
 `<div class="sr dd" data-k="${s[0]}"><button class="ddb"><span>${s[1]}</span><b>${txt(s[3],D.set[s[0]])}</b><i class="chev"></i></button><div class="ddm"><div><div class="ddl">${s[3].map(([v,t])=>`<button class="ddi${D.set[s[0]]==v?' on':''}" data-v="${v}">${t}</button>`).join('')}</div></div></div></div>`).join('')+
 '<div class="sbtn"><button class="pill" id="xCp">Copy times</button><button class="pill" id="xRn">Rename session</button><button class="pill" id="xClr">Clear session</button><button class="pill" id="xDel">Delete session</button></div>';lockI()}
function lockI(){['insp','ilen','alert'].forEach(k=>{const e=$('xBody').querySelector(`[data-k="${k}"]`);if(e)e.closest('.sr').classList.toggle('off',!!D.set.two)})}
function lay(){bgApply();document.documentElement.classList.toggle('light',!D.set.dark);{const t=$('tc');if(t)t.content=D.set.dark?'#000000':'#f3f4f8'}themeBtn();try{SFX.cfg({ui:true,vol:100})}catch(e){}V.classList.toggle('two',!!D.set.two);V.classList.toggle('p2',D.set.two==2);V.classList.toggle('p2r',D.set.two==2&&D.set.side==1);padLbl();V.classList.toggle('hide',!!D.set.hide);$('xScr').dataset.z=D.set.ssz;$('xBulb').classList.toggle('on',!!D.set.insp)}
function apply(k){save();lay();if(k=='diff'){gen();render()}if(k=='vol')setTimeout(()=>P('pick'),0);if(k=='ui'&&D.set.ui)setTimeout(()=>P('on'),0);if(k=='keep')wake();if(k=='two'){tab(0);lockI();if(D.set.two!=2)lkClose();buildS();if(D.set.two==2&&!LK.ok)lkOpen()}render()}
$('xSet').onclick=()=>{buildS();$('xS').classList.add('on')};
$('xS').onclick=e=>{if(e.target.id=='xS'||e.target.closest('#xX'))$('xS').classList.remove('on')};
$('xBody').onclick=e=>{const t=e.target,sw=t.closest('.sw'),b=t.closest('.ddb'),it=t.closest('.ddi');
 if(sw){const k=sw.dataset.k;D.set[k]=D.set[k]?0:1;sw.classList.toggle('on');sw.setAttribute('aria-checked',!!D.set[k]);apply(k)}
 else if(b){const d=b.parentNode,o=d.classList.contains('open');$('xBody').querySelectorAll('.dd.open').forEach(x=>x.classList.remove('open'));d.classList.toggle('open',!o)}
 else if(it){const d=it.closest('.dd'),k=d.dataset.k;D.set[k]=+it.dataset.v;d.querySelectorAll('.ddi').forEach(x=>x.classList.toggle('on',x==it));d.querySelector('.ddb b').textContent=it.textContent;d.classList.remove('open');apply(k)}
 else if(t.id=='lkOpen')lkOpen();
 else if(t.id=='bgPick')$('bgFile').click();
 else if(t.id=='bgClr'){bgSet(null);vidClear();$('bgSt').textContent='None';t.disabled=true}
 else if(t.id=='xCp'&&navigator.clipboard)navigator.clipboard.writeText(ses().t.map((r,i)=>(i+1)+'. '+lab(r)+'  '+r.s).join('\n')).then(()=>t.textContent='Copied ✓');
 else if(t.id=='xRn'){const n=(prompt('Session name',ses().n)||'').trim().slice(0,24);if(n){ses().n=n;save();opts();render()}}
 else if(t.id=='xClr')ask($('dS'),'Clear this session?','All times in it will be deleted.','Clear').then(y=>{if(y){P('del');ses().t=[];sel.clear();ex=-1;shown=false;save();render();opts()}})
 else if(t.id=='xDel'){if(DS().S.length<2||M=='w')ask($('dS'),'Can\u2019t delete',M=='w'?'Weak case sessions are built in. Use Clear session to reset them.':'You need at least one session.','OK',1);else ask($('dS'),'Delete this session?','The session and all its times will be deleted.','Delete').then(y=>{if(y){DS().S.splice(DS().c,1);DS().c=0;sel.clear();ex=-1;shown=false;save();opts();gen();render();$('xS').classList.remove('on')}})}};
// background image (kept on the device, shrunk first so it fits in storage)
const BGK='x9bg',root=document.documentElement;
function bgHas(){return document.body.classList.contains('hasbg')}
function bgSet(u){try{if(u)localStorage.setItem(BGK,u);else localStorage.removeItem(BGK)}catch(e){return false}
 if(u)root.style.setProperty('--bgimg','url("'+u+'")');else root.style.removeProperty('--bgimg');document.body.classList.toggle('hasbg',!!u);return true}
function bgApply(){root.style.setProperty('--bgdim',D.set.bgdim/100);root.style.setProperty('--bgblur',D.set.bgblur+'px')}
function shrink(f,max,q){return new Promise((ok,no)=>{const u=URL.createObjectURL(f),i=new Image();i.onload=()=>{const k=Math.min(1,max/Math.max(i.width,i.height)),c=document.createElement('canvas');c.width=Math.max(1,Math.round(i.width*k));c.height=Math.max(1,Math.round(i.height*k));c.getContext('2d').drawImage(i,0,0,c.width,c.height);URL.revokeObjectURL(u);ok(c.toDataURL('image/jpeg',q))};i.onerror=()=>{URL.revokeObjectURL(u);no()};i.src=u})}
$('bgFile').onchange=async e=>{const f=e.target.files[0];e.target.value='';if(!f)return;const st=()=>$('bgSt'),say=t=>{if(st())st().textContent=t};say('Loading…');
 if(f.type.startsWith('video/')||/\.(mp4|webm|mov|m4v|mkv)$/i.test(f.name)){
  if(f.size>200*1048576){say('Video too large (max 200 MB)');return}
  try{const th=await vidThumb(f);await IDB.set('bg',f);if(!bgSet(th)){await IDB.set('bg',null);say('Could not save');return}vidShow(f);P('save');say('Custom video');const c=$('bgClr');if(c)c.disabled=false}catch(_){say('Could not read that video')}
  return}
 try{vidClear();let done=false;for(const [m,q] of [[1600,.82],[1200,.74],[900,.66]]){if(bgSet(await shrink(f,m,q))){done=true;break}}
  if(done){P('save');say('Custom image');const c=$('bgClr');if(c)c.disabled=false}else say('Image too large to save')}catch(_){say('Could not read that image')}};
try{const u=localStorage.getItem(BGK);if(u){root.style.setProperty('--bgimg','url("'+u+'")');document.body.classList.add('hasbg')}}catch(e){}
// background video: the file lives in IndexedDB (too big for localStorage); a still frame is kept as the image fallback
const IDB={db(){return new Promise((ok,no)=>{const r=indexedDB.open('x9',1);r.onupgradeneeded=()=>r.result.createObjectStore('f');r.onsuccess=()=>ok(r.result);r.onerror=()=>no(r.error)})},
 async get(k){const d=await this.db();return new Promise((ok,no)=>{const q=d.transaction('f').objectStore('f').get(k);q.onsuccess=()=>ok(q.result);q.onerror=()=>no(q.error)})},
 async set(k,v){const d=await this.db();return new Promise((ok,no)=>{const t=d.transaction('f','readwrite'),o=t.objectStore('f');v==null?o.delete(k):o.put(v,k);t.oncomplete=()=>ok(true);t.onerror=()=>no(t.error)})}};
let vUrl=null;
function vidSync(){if(!document.body.classList.contains('hasvid'))return;if(LT)vidStop();else IDB.get('bg').then(b=>b&&vidShow(b)).catch(()=>{})}
function vidStop(){const v=$('bgv');v.pause();v.removeAttribute('src');v.load();if(vUrl){URL.revokeObjectURL(vUrl);vUrl=null}}
function vidShow(b){const v=$('bgv');if(LT){document.body.classList.add('hasvid','hasbg');vidStop();return}if(vUrl)URL.revokeObjectURL(vUrl);vUrl=URL.createObjectURL(b);v.src=vUrl;document.body.classList.add('hasvid','hasbg');v.play().catch(()=>{})}
function vidClear(){const v=$('bgv');document.body.classList.remove('hasvid');v.pause();v.removeAttribute('src');v.load();if(vUrl){URL.revokeObjectURL(vUrl);vUrl=null}IDB.set('bg',null).catch(()=>{})}
function vidThumb(f){return new Promise((ok,no)=>{const u=URL.createObjectURL(f),v=document.createElement('video');v.muted=true;v.playsInline=true;v.preload='auto';
 const bad=()=>{URL.revokeObjectURL(u);no()};v.onerror=bad;
 v.onloadeddata=()=>{v.currentTime=Math.min(.1,(v.duration||1)/2)};
 v.onseeked=()=>{try{const k=Math.min(1,720/Math.max(v.videoWidth,v.videoHeight)),c=document.createElement('canvas');c.width=Math.max(1,Math.round(v.videoWidth*k));c.height=Math.max(1,Math.round(v.videoHeight*k));c.getContext('2d').drawImage(v,0,0,c.width,c.height);const d=c.toDataURL('image/jpeg',.7);URL.revokeObjectURL(u);ok(d)}catch(e){bad()}};
 v.src=u});}
IDB.get('bg').then(b=>{if(b&&document.body.classList.contains('hasbg'))vidShow(b)}).catch(()=>{});
document.addEventListener('visibilitychange',()=>{const v=$('bgv');if(document.hidden&&sv)flush();if(!document.body.classList.contains('hasvid')||LT)return;if(document.hidden)v.pause();else v.play().catch(()=>{})});
function themeBtn(){const b=$('hmTheme');if(b){b.classList.toggle('on',!!D.set.dark);b.setAttribute('aria-pressed',!!D.set.dark)}}
$('hmTheme')&&($('hmTheme').onclick=()=>{const root=document.documentElement;root.classList.add('theme-transition');D.set.dark^=1;save();lay();P(D.set.dark?'off':'on');setTimeout(()=>root.classList.remove('theme-transition'),560)});
function hmSnd(){const b=$('hmSnd');if(!b)return;b.classList.toggle('on',!!D.set.ui);b.setAttribute('aria-pressed',!!D.set.ui)}


// tap the cube layout to enlarge it in the middle; tap anywhere to send it back
(()=>{const n=$('xNet'),z=$('netZ'),zs=$('netZS');let op=0,an=null;
 const geo=()=>{const a=n.getBoundingClientRect(),b=zs.getBoundingClientRect();return{dx:a.left+a.width/2-(b.left+b.width/2),dy:a.top+a.height/2-(b.top+b.height/2),s:a.width/b.width}};
 const fly=(r,rev)=>{const f=[{transform:`translate(${r.dx}px,${r.dy}px) scale(${r.s})`},{transform:'none'}];if(rev)f.reverse();if(an)an.cancel();an=zs.animate(f,{duration:rev?240:320,easing:'cubic-bezier(.2,.9,.25,1)',fill:'both'});return an.finished.catch(()=>{})};
 function open(){if(op||st!='idle')return;op=1;const g=$('xNetS');zs.setAttribute('viewBox',g.getAttribute('viewBox'));zs.innerHTML=g.innerHTML;
  z.classList.add('on');n.style.visibility='hidden';fly(geo(),0);P('flip')}
 function close(){if(!op)return;op=0;z.classList.remove('shown');z.classList.add('out');fly(geo(),1).then(()=>{if(op)return;z.classList.remove('on','out');n.style.visibility='';if(an)an.cancel()})}
 n.onclick=open;z.addEventListener('pointerdown',e=>{e.preventDefault();e.stopPropagation();close()});
 addEventListener('popstate',()=>{if(op){op=0;z.classList.remove('on','out');n.style.visibility='';if(an)an.cancel()}});
 addEventListener('keydown',e=>{if(op&&(e.key=='Escape'||e.code=='Space')){e.preventDefault();e.stopPropagation();close()}},true)})();
addEventListener('pagehide',flush);
// automatic performance + battery saving (no setting): slow phones, data saver, battery saver or a low battery switch the light mode on by themselves
const RT=document.documentElement;let bat=null;
function autoPerf(){const n=navigator,c=n.connection,low=bat&&!bat.charging&&bat.level<=.2,
  on=(n.hardwareConcurrency||8)<=4||(n.deviceMemory||8)<=3||(c&&c.saveData)||low||matchMedia('(prefers-reduced-data: reduce)').matches?1:0;
 if(on===LT&&RT.classList.contains('lite')==!!on)return;LT=on;RT.classList.toggle('lite',!!on);vidSync()}
try{navigator.getBattery&&navigator.getBattery().then(b=>{bat=b;['levelchange','chargingchange'].forEach(n=>b.addEventListener(n,autoPerf));autoPerf()}).catch(()=>{})}catch(e){}
// nothing animates while the app is in the background, and the home glow stops after a few idle seconds
const calmT=()=>{clearTimeout(window._cl);HM.classList.remove('calm');if(document.body.dataset.v=='home')window._cl=setTimeout(()=>HM.classList.add('calm'),8000)};
document.addEventListener('visibilitychange',()=>{RT.classList.toggle('bgd',document.hidden);if(!document.hidden)calmT()});
new MutationObserver(calmT).observe($('vhome'),{attributes:true,attributeFilter:['class']});
HM.addEventListener('pointerdown',calmT,{passive:true});
autoPerf();calmT();
window.X9={ask};
setTimeout(()=>(window.requestIdleCallback||setTimeout)(()=>{try{X9C.init()}catch(e){}}),4200);
lay();opts();gen();render();
})();

addEventListener('visibilitychange',()=>{if(!document.hidden)LK.seen=Date.now()});