/* X9 Weak Case Mode engine (no DOM except mini()): OLL + PLL case lists, scrambles that set up one case,
   which case to show next (weak ones come up more), and how each case is doing. */
(function(root){
'use strict';
var C=root.PLLC||(typeof require!=='undefined'?require('./pllcore.js'):null);
if(!C)return;

// ---- OLL 1-57 (one common algorithm each; edit here if you prefer another) ----
var OLL=[
"R U2 R2 F R F' U2 R' F R F'","r U r' U2 r U2 R' U2 R U' r'","r' R2 U R' U r U2 r' U M'","M U' r U2 r' U' R U' R' M'",
"r' U2 R U R' U r","r U2 R' U' R U' r'","r U R' U R U2 r'","r' U' R U' R' U2 r",
"R U R' U' R' F R2 U R' U' F'","R U R' U R' F R F' R U2 R'","r U R' U R' F R F' R U2 r'","M' R' U' R U' R' U2 R U' M",
"F U R U2 R' U' R U R' F'","R' F R U R' F' R F U' F'","r' U' r R' U' R U r' U r","r U r' R U R' U' r U' r'",
"R U R' U R' F R F' U2 R' F R F'","r U R' U R U2 r2 U' R U' R' U2 r","r' R U R U R' U' M' R' F R F'","r U R' U' M2 U R U' R' U' M'",
"R U2 R' U' R U R' U' R U' R'","R U2 R2 U' R2 U' R2 U2 R","R2 D R' U2 R D' R' U2 R'","r U R' U' r' F R F'",
"F' r U R' U' r' F R","R U2 R' U' R U' R'","R U R' U R U2 R'","r U R' U' r' R U R U' R'",
"R U R' U' R U' R' F' U' F R U R'","F R' F R2 U' R' U' R U R' F2","R' U' F U R U' R' F' R","L U F' U' L' U L F L'",
"R U R' U' R' F R F'","R U R2 U' R' F R U R U' F'","R U2 R2 F R F' R U2 R'","R' U' R U' R' U R U R B' R' B",
"F R' F' R U R U' R'","R U R' U R U' R' U' R' F R F'","R U R' F' U' F U R U2 R'","R' F R U R' U' F' U R",
"R U R' U R U2 R' F R U R' U' F'","R' U' R U' R' U2 R F R U R' U' F'","R' U' F' U F R","F U R U' R' F'",
"F R U R' U' F'","R' U' R' F R F' U R","F' L' U' L U L' U' L U F","F R U R' U' R U R' U' F'",
"r U' r2 U r2 U r2 U' r","r' U r2 U' r2 U' r2 U r'","F U R U' R' U R U' R' F'","R U R' U R U' B U' B' R'",
"r' U' R U' R' U R U' R' U2 r","r U R' U R U' R' U R U2 r'","R U2 R2 U' R U' R' U2 F R F'","r U r' U R U' R' U R U' R' r U' r'",
"R U R' U' M' U R U' r'"];
// ---- the 21 PLLs come from the PLL engine ----
var PLL=C.CASES;

function list(sub){return sub=='oll'?OLL.map(function(a,i){return{k:'OLL '+(i+1),alg:a}}):PLL.map(function(c){return{k:c.name,alg:c.alg}})}

// ---- turn any algorithm (slices, wide moves, rotations) into plain U R F D L B turns ----
var NEXT={x:{U:'F',F:'D',D:'B',B:'U',R:'R',L:'L'},y:{F:'R',R:'B',B:'L',L:'F',U:'U',D:'D'},z:{R:'U',D:'R',L:'D',U:'L',F:'F',B:'B'}};
function spin(fm,ax,n){n=((n%4)+4)%4;while(n--){var o={};for(var f in fm)o[f]=fm[NEXT[ax][f]];fm=o}return fm}
function faceOnly(alg){
 var fm={U:'U',D:'D',F:'F',B:'B',R:'R',L:'L'},out=[],t=alg.trim().split(/\s+/),i;
 var emit=function(f,k){k=((k%4)+4)%4;if(!k)return;var g=fm[f],l=out[out.length-1];
  if(l&&l.f==g){l.k=(l.k+k)%4;if(!l.k)out.pop()}else out.push({f:g,k:k})};
 for(i=0;i<t.length;i++){if(!t[i])continue;
  var m=/^([URFDLBMESxyzurfdlb])(w?)(2'?|')?$/.exec(t[i]);if(!m)throw new Error('bad move '+t[i]);
  var f=m[1],k=m[3]?(m[3]=="'"?3:2):1;if(m[2]&&f==f.toUpperCase())f=f.toLowerCase();
  // each move = outer face turns + a whole-cube rotation that carries the frame along
  switch(f){
   case'U':case'R':case'F':case'D':case'L':case'B':emit(f,k);break;
   case'M':emit('R',k);emit('L',-k);fm=spin(fm,'x',-k);break;
   case'E':emit('U',k);emit('D',-k);fm=spin(fm,'y',-k);break;
   case'S':emit('F',-k);emit('B',k);fm=spin(fm,'z',k);break;
   case'r':emit('L',k);fm=spin(fm,'x',k);break;
   case'l':emit('R',k);fm=spin(fm,'x',-k);break;
   case'u':emit('D',k);fm=spin(fm,'y',k);break;
   case'd':emit('U',k);fm=spin(fm,'y',-k);break;
   case'f':emit('B',k);fm=spin(fm,'z',k);break;
   case'b':emit('F',k);fm=spin(fm,'z',-k);break;
   default:fm=spin(fm,f,k)}}
 return out.map(function(m){return m.f+(m.k==1?'':m.k==2?'2':"'")}).join(' ')}
function inv(s){return s.trim().split(/\s+/).reverse().map(function(t){return t[1]=="'"?t[0]:t[1]=='2'?t:t[0]+"'"}).join(' ')}
var AUF=['','U','U2',"U'"];
// scramble that leaves exactly this case on a cube whose first two layers are solved (a = turn before, b = turn after)
function scramble(sub,i,a,b){var c=list(sub)[i],s=(AUF[a|0]+' '+C.inverse(c.alg)+' '+AUF[b|0]).trim();return faceOnly(s)}

// ---- tiny top-down picture of a case ----
function mini(sub,i){var c=list(sub)[i],s=C.solved(),sc=C.scheme('white'),h='',oll=sub=='oll',r,q,x,y,w,hh,f,col;
 C.apply(s,AUF[0]+C.inverse(c.alg));s=C.fixOrient(s);
 for(r=0;r<3;r++)for(var k=0;k<3;k++)h+='<rect x="'+(15+k*10)+'" y="'+(15+r*10)+'" width="10" height="10" fill="#555"/>';
 for(q=0;q<s.length;q++){var t=s[q];if(t.p[1]!=1)continue;f=t.f;
  col=oll?(f=='U'?sc.U:'#555'):sc[f];
  if(t.n[1]==1){if(oll&&f=='U')h+='<rect x="'+(15+(t.p[0]+1)*10)+'" y="'+(15+(t.p[2]+1)*10)+'" width="10" height="10" fill="'+sc.U+'"/>';else if(!oll)h+='<rect x="'+(15+(t.p[0]+1)*10)+'" y="'+(15+(t.p[2]+1)*10)+'" width="10" height="10" fill="'+sc.U+'"/>';continue}
  w=10;hh=5;
  if(t.n[2]==1){x=15+(t.p[0]+1)*10;y=46}else if(t.n[2]==-1){x=15+(t.p[0]+1)*10;y=9}
  else if(t.n[0]==1){x=46;y=15+(t.p[2]+1)*10;w=5;hh=10}else{x=9;y=15+(t.p[2]+1)*10;w=5;hh=10}
  h+='<rect x="'+x+'" y="'+y+'" width="'+w+'" height="'+hh+'" rx="1" fill="'+col+'"/>'}
 return'<svg viewBox="0 0 60 60" aria-hidden="true">'+h+'</svg>'}

// ---- statistics ----
var val=function(r){return r.p==3?Infinity:r.t+(r.p==2?2000:0)};
function byCase(sub,solves){var m={};list(sub).forEach(function(c){m[c.k]=[]});solves.forEach(function(r){if(r.k&&m[r.k])m[r.k].push(r)});return m}
var med=function(a){var v=a.slice().sort(function(x,y){return x-y}),n=v.length;return n?(n%2?v[(n-1)/2]:(v[n/2-1]+v[n/2])/2):null};
var MINN=2; // solves of a case before it is rated
// one case: average of its last 5 solves; a DNF counts as 1.5x its slowest solve (or 20 s)
function score(rs){var a=rs.slice(-5).map(val),f=a.filter(isFinite),mx=f.length?Math.max.apply(null,f):13333,pen=mx*1.5,t=0;
 a.forEach(function(v){t+=isFinite(v)?v:pen});return a.length?t/a.length:null}
function rate(sub,solves){var m=byCase(sub,solves),out=[];
 list(sub).forEach(function(c,i){var rs=m[c.k],f=rs.map(val).filter(isFinite);
  out.push({i:i,k:c.k,n:rs.length,score:rs.length?score(rs):null,best:f.length?Math.min.apply(null,f):null,dnf:rs.filter(function(r){return r.p==3}).length})});
 return out}
// good / worst: rated cases only, slowest half = worst, fastest half = good
function split(sub,solves){var r=rate(sub,solves).filter(function(x){return x.n>=MINN&&x.score!=null}).sort(function(a,b){return a.score-b.score}),h=Math.floor(r.length/2);
 return{good:r.slice(0,Math.max(h,r.length==1?1:0)),worst:r.slice(r.length==1?0:h).reverse(),rated:r.length,total:list(sub).length}}
// what the last solve says about that case: compared with the median of the earlier solves of the same case
function verdict(sub,solves,r){var prev=byCase(sub,solves.filter(function(x){return x!==r}))[r.k]||[],v=prev.map(val).filter(isFinite);
 if(r.p==3)return{v:'bad',t:'DNF'};
 if(v.length<MINN)return{v:'new',t:'Learning this case · '+v.length+'/'+MINN};
 var b=med(v),x=val(r);
 return x<=b*1.1?{v:'good',t:'Good execution'}:x>b*1.35?{v:'bad',t:'Slow execution'}:{v:'ok',t:'Normal'}}
// next case: unseen / barely seen cases first, then the slower a case is (compared with your average) the more often it comes
function pick(sub,solves,last){var rs=rate(sub,solves),sc=rs.filter(function(x){return x.score!=null&&x.n>=MINN}),mean=sc.length?sc.reduce(function(s,x){return s+x.score},0)/sc.length:0,w=rs.map(function(x){
  if(x.k==last)return 0;if(x.n<MINN)return 3;return Math.max(.3,Math.min(3,.4+1.6*x.score/(mean||1)))}),
  tot=w.reduce(function(s,x){return s+x},0),p=Math.random()*tot,i;
 for(i=0;i<w.length;i++){p-=w[i];if(p<=0)return i}return 0}

root.WK={list:list,scramble:scramble,mini:mini,rate:rate,split:split,verdict:verdict,pick:pick,faceOnly:faceOnly,MINN:MINN,count:function(s){return list(s).length}};
if(typeof module!=='undefined')module.exports=root.WK;
})(typeof window!=='undefined'?window:globalThis);
