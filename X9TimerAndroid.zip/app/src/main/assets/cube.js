/* X9 cube engine: NxN sticker model (2x2-5x5), net layout, and cross-solved F2L scrambles.
   Coordinates are doubled integers so even cubes have integer positions.
   Axes: x = right, y = up, z = toward the viewer (F). */
(function(root){
'use strict';
var CW={x:function(v){return[v[0],v[2],-v[1]]},y:function(v){return[-v[2],v[1],v[0]]},z:function(v){return[v[1],-v[0],v[2]]}};
// face -> [rotation axis, side sign, quarter-turns of CW[axis] that make a clockwise face turn]
var MV={R:['x',1,1],L:['x',-1,3],U:['y',1,1],D:['y',-1,3],F:['z',1,1],B:['z',-1,3]};
var AX={x:0,y:1,z:2},FN={R:[1,0,0],L:[-1,0,0],U:[0,1,0],D:[0,-1,0],F:[0,0,1],B:[0,0,-1]};
var FACES='URFDLB',AXOF={U:0,D:0,R:1,L:1,F:2,B:2};

function makeCube(N){var s=[],m=N-1;
 for(var fi=0;fi<6;fi++){var f=FACES[fi],n=FN[f],a=n.findIndex(function(v){return v}),o=[0,1,2].filter(function(i){return i!=a});
  for(var i=0;i<N;i++)for(var j=0;j<N;j++){var p=[0,0,0];p[a]=n[a]*m;p[o[0]]=2*i-m;p[o[1]]=2*j-m;s.push({p:p,n:n.slice(),f:f})}}
 return s}
function parse(str){var out=[],t=(str||'').trim().split(/\s+/);
 for(var i=0;i<t.length;i++){var m=/^([URFDLB])(w?)(2|'|)$/.exec(t[i]);if(m)out.push({f:m[1],w:m[2]?2:1,k:m[3]=='2'?2:m[3]=="'"?3:1})}
 return out}
function turn(s,N,mv){var d=MV[mv.f],ax=d[0],sg=d[1],a=AX[ax],lim=N-1-2*(mv.w-1),times=mv.k*d[2];
 for(var i=0;i<s.length;i++){var q=s[i];if(sg*q.p[a]>=lim)for(var t=0;t<times;t++){q.p=CW[ax](q.p);q.n=CW[ax](q.n)}}}

// ---- net (U on top, L F R B across, D below) ----
var OFF={U:[1,0],L:[0,1],F:[1,1],R:[2,1],B:[3,1],D:[1,2]},NET_ORDER='ULFRBD',GAP=.32;
function cell(q,N){var m=N-1,x=q.p[0],y=q.p[1],z=q.p[2],n=q.n,f,c,r;
 if(n[1]==1){f='U';c=x;r=z}else if(n[1]==-1){f='D';c=x;r=-z}
 else if(n[2]==1){f='F';c=x;r=-y}else if(n[2]==-1){f='B';c=-x;r=-y}
 else if(n[0]==1){f='R';c=-z;r=-y}else{f='L';c=z;r=-y}
 return[f,(c+m)/2,(r+m)/2]}
function netLayout(N){var out=[];
 for(var k=0;k<6;k++){var f=NET_ORDER[k],o=OFF[f];
  for(var r=0;r<N;r++)for(var c=0;c<N;c++)out.push({x:o[0]*(N+GAP)+c,y:o[1]*(N+GAP)+r})}
 return{cells:out,w:4*N+3*GAP,h:3*N+2*GAP}}
// returns, for every net cell in layout order, the face letter whose colour belongs there
function net(N,scr){var s=makeCube(N),mv=parse(scr),i;
 for(i=0;i<mv.length;i++)turn(s,N,mv[i]);
 var g={};NET_ORDER.split('').forEach(function(f){g[f]=[]});
 for(i=0;i<s.length;i++){var c=cell(s[i],N);g[c[0]][c[2]*N+c[1]]=s[i].f}
 var out=[];NET_ORDER.split('').forEach(function(f){out=out.concat(g[f])});return out}

// ---- cross solver (3x3): 4 D-cross edges, BFS table over 190,080 states ----
var SL=[],SLI={},PERM=null,MVL=[],DIST=null,CROSS0=null;
// random numbers from the system generator, drawn in batches so scrambles never depend on a fixed list or seed
var RB=new Uint32Array(2048),ri=2048;
function rnd(){if(ri>=2048){try{crypto.getRandomValues(RB)}catch(e){for(var i=0;i<2048;i++)RB[i]=Math.random()*4294967296>>>0}ri=0}return RB[ri++]/4294967296}
var sk=function(p,n){return p.join()+'|'+n.join()};
function init(){if(DIST)return;
 var cube=makeCube(3),i,j;
 for(i=0;i<cube.length;i++){var q=cube[i],a=q.n.findIndex(function(v){return v}),zeros=0;
  for(j=0;j<3;j++)if(j!=a&&q.p[j]==0)zeros++;
  if(zeros==1){SLI[sk(q.p,q.n)]=SL.length;SL.push({p:q.p.slice(),n:q.n.slice()})}}
 PERM=[];
 for(var fi=0;fi<6;fi++)for(var k=1;k<=3;k++){var mv={f:FACES[fi],w:1,k:k},pm=new Uint8Array(24);
  for(i=0;i<24;i++){var t={p:SL[i].p.slice(),n:SL[i].n.slice()};turn([t],3,mv);pm[i]=SLI[sk(t.p,t.n)]}
  PERM.push(pm);MVL.push(mv)}
 CROSS0=[[0,-2,2],[2,-2,0],[0,-2,-2],[-2,-2,0]].map(function(p){return SLI[sk(p,[0,-1,0])]});
 DIST=new Int8Array(331776).fill(-1);
 var key=function(s){return((s[0]*24+s[1])*24+s[2])*24+s[3]},Q=new Int32Array(190081),h=0,t=0,k0=key(CROSS0);DIST[k0]=0;Q[t++]=k0;
 while(h<t){var k=Q[h++],d=DIST[k],a=k/13824|0,b=(k/576|0)%24,c=(k/24|0)%24,e=k%24;
  for(var m=0;m<18;m++){var pm=PERM[m],kk=((pm[a]*24+pm[b])*24+pm[c])*24+pm[e];if(DIST[kk]<0){DIST[kk]=d+1;Q[t++]=kk}}}
 init.key=key}
function crossSolve(state){init();var key=init.key,d=DIST[key(state)],out=[];
 while(d>0){var c=[];
  for(var m=0;m<18;m++){var pm=PERM[m],ns=[pm[state[0]],pm[state[1]],pm[state[2]],pm[state[3]]];if(DIST[key(ns)]==d-1)c.push([m,ns])}
  var pick=c[rnd()*c.length|0];out.push(MVL[pick[0]]);state=pick[1];d--}
 return out}
function reduce(list){var out=[];
 for(var i=0;i<list.length;i++){var mv={f:list[i].f,k:list[i].k},j=out.length-1;
  while(j>=0&&AXOF[out[j].f]==AXOF[mv.f]&&out[j].f!=mv.f)j--;
  if(j>=0&&out[j].f==mv.f){var k=(out[j].k+mv.k)%4;if(k)out[j].k=k;else out.splice(j,1)}else out.push(mv)}
 return out}
var fmt=function(l){return l.map(function(m){return m.f+['','2',"'"][m.k-1]}).join(' ')};
// A random 3x3 scramble that leaves the white cross solved on D (cube held white-bottom, green-front).
function f2lScramble(len){init();len=len||18;
 var seq=[],l='',p='';
 while(seq.length<len){var f=FACES[rnd()*6|0];
  if(f==l||(AXOF[f]==AXOF[l]&&AXOF[p]==AXOF[l]))continue;
  seq.push({f:f,k:1+(rnd()*3|0)});p=l;l=f}
 var state=CROSS0.slice();
 seq.forEach(function(mv){var pm=PERM[FACES.indexOf(mv.f)*3+mv.k-1];state=[pm[state[0]],pm[state[1]],pm[state[2]],pm[state[3]]]});
 return fmt(reduce(seq.concat(crossSolve(state))))}

// optimal cross length (HTM) of a 3x3 scramble string, and a hand-picked scramble for a difficulty (0 easy, 1 any, 2 hard)
// white cross: the cube is flipped with z2 (white to the bottom, green stays front), so U<->D and R<->L
function z2s(s){return s.replace(/[UDRL]/g,function(c){return{U:'D',D:'U',R:'L',L:'R'}[c]})}
function crossState(scr){init();var st=CROSS0.slice(),mv=parse(scr),i;
 for(i=0;i<mv.length;i++){var pm=PERM[FACES.indexOf(mv[i].f)*3+mv[i].k-1];st=[pm[st[0]],pm[st[1]],pm[st[2]],pm[st[3]]]}
 return st}
function crossHint(scr){var sol=crossSolve(crossState(z2s(scr)));return sol.length?'z2 '+fmt(sol):''}
function crossDist(scr){scr=z2s(scr);init();var st=CROSS0.slice(),mv=parse(scr),i;
 for(i=0;i<mv.length;i++){var pm=PERM[FACES.indexOf(mv[i].f)*3+mv[i].k-1];st=[pm[st[0]],pm[st[1]],pm[st[2]],pm[st[3]]]}
 return DIST[init.key(st)]}
// extend a scramble with the first moves of its optimal cross solution so the cross is exactly lv moves from solved (needs lv <= current length)
function crossTo(scr,lv){var sol=fmt(crossSolve(crossState(z2s(scr)))).split(' ').filter(Boolean),k=sol.length-lv;return k>0?scr+' '+z2s(sol.slice(0,k).join(' ')):scr}
function pickByCross(level,make){var s=make();if(!level)return s;
 for(var i=0;i<4000;i++){var d=crossDist(s);if(level==1?d<=4:d>=7)return s;s=make()}return s}
root.X9C={crossTo:crossTo,rnd:rnd,crossHint:crossHint,z2s:z2s,crossDist:crossDist,pickByCross:pickByCross,makeCube:makeCube,parse:parse,turn:turn,net:net,netLayout:netLayout,init:init,f2lScramble:f2lScramble};
if(typeof module!=='undefined')module.exports=root.X9C;
})(typeof window!=='undefined'?window:globalThis);
