/* X9Timer startup screen: scrambled tiles flip in, the face "solves" with a chime, the title shines in. */
(()=>{
const el=document.getElementById('intro');if(!el)return;
const $=i=>document.getElementById(i),tick=$('inTick');
let sound=true;try{const s=JSON.parse(localStorage.getItem('x9'));if(s&&s.set&&+s.set.ui===0)sound=false}catch(e){}
const calm=matchMedia('(prefers-reduced-motion: reduce)').matches;
let ac=null,finished=false,armed=false,introOn=false,tmr=[];
const later=(f,ms)=>tmr.push(setTimeout(f,ms));let exited=false;

// floating dust
const lite=document.documentElement.classList.contains('lite');
$('inDots').innerHTML=Array.from({length:lite?0:16},()=>`<i style="--x:${(Math.random()*100).toFixed(1)}%;--s:${(1+Math.random()*2.2).toFixed(1)}px;--t:${(5+Math.random()*5).toFixed(1)}s;--w:-${(Math.random()*8).toFixed(1)}s"></i>`).join('');

// ---- sound: uses the shared engine in sfx.js (louder, new sounds) ----
function chain(){ac=SFX.ac();if(!ac)throw 0}
const fullSfx=t=>SFX.run('intro',t),leaveSfx=t=>SFX.run('exit',t);

// ---- scramble ticker ----
const FACES='URFDLB',SUF=['',"'",'2'];let tk=0;
function startTicker(){tk=setInterval(()=>{let l='',s=[];while(s.length<5){const f=FACES[Math.random()*6|0];if(f==l)continue;l=f;s.push(f+SUF[Math.random()*3|0])}tick.textContent=s.join(' ')},85)}

function leave(){if(finished)return;finished=true;clearInterval(tk);tmr.forEach(clearTimeout);
 if(introOn)SFX.fadeIntro(260);else if(!exited&&ac&&ac.state=='running'&&sound){exited=true;leaveSfx(ac.currentTime+.02)}
 el.classList.remove('wait');el.classList.add('out');setTimeout(()=>el.remove(),700)}
function ready(){clearInterval(tk);tick.textContent='Ready';tick.classList.add('rdy')}

// tapping the screen skips it; if the browser blocked autoplay, this tap is what unlocks the sound
el.addEventListener('pointerdown',async()=>{
 if(finished)return;
 if(sound&&ac&&ac.state!='running'&&!armed){armed=true;try{await ac.resume()}catch(e){}if(ac.state=='running')later(leave,520);return}
 leave()});

(async()=>{
 let live=false;
 if(sound&&!calm){try{chain();if(ac.state!='running')await Promise.race([ac.resume().catch(()=>0),new Promise(r=>setTimeout(r,140))]);live=ac.state=='running'}catch(e){ac=null}}
 if(live)await Promise.race([SFX.ready('intro'),new Promise(r=>setTimeout(r,350))]);
 el.classList.add('go');
 if(calm){ready();later(leave,900);return}
 startTicker();
 if(live){introOn=true;fullSfx(ac.currentTime+.03)}
 later(ready,2150);
 later(()=>{if(finished)return;if(sound&&ac&&!live){el.classList.add('wait')}else leave()},3000);
 later(leave,live||!sound?3350:12000);
})();
// never leave the app stuck behind the splash
setTimeout(()=>{if(!finished&&!el.classList.contains('wait'))leave()},14000);
})();
